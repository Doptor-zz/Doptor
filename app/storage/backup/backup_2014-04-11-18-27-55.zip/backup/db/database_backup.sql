-- SQL Dump
-- Server version:5.5.36-cll
-- Generated: 2014-04-11 06:27:55
-- Current PHP version: 5.3.28
-- Host: localhost
-- Database:tngbdcom_mjtest

-- --------------------------------------------------------
-- Structure for 'built_forms'
--

DROP TABLE IF EXISTS built_forms;
-- --------------------------------------------------------

CREATE TABLE `built_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` int(10) unsigned NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `rendered` text COLLATE utf8_unicode_ci NOT NULL,
  `redirect_to` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `extra_code` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `built_forms_category_index` (`category`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `built_forms`
--

INSERT INTO built_forms (`id`,`name`,`category`,`description`,`data`,`rendered`,`redirect_to`,`extra_code`,`created_at`,`updated_at`) VALUES ('17','rana','1','','[{"title":"Form Name","fields":{"name":{"label":"Form Name","type":"input","value":"rana","name":"name"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinput13123120","name":"id"},"label":{"label":"Label Text","type":"input","value":"Name","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":true,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}}]','<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>rana</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput13123120">Name</label>
  <div class="controls">
    <input id="textinput13123120" name="textinput13123120" placeholder="" class="input-xlarge" required="" type="text">
    
  </div>
</div>

</fieldset>
</form>
','list','','2014-04-10 07:38:33','2014-04-10 07:38:33');

-- --------------------------------------------------------
INSERT INTO built_forms (`id`,`name`,`category`,`description`,`data`,`rendered`,`redirect_to`,`extra_code`,`created_at`,`updated_at`) VALUES ('15','new form','1','','[{"title":"Form Name","fields":{"name":{"label":"Form Name","type":"input","value":"new form","name":"name"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinput","name":"id"},"label":{"label":"Label Text","type":"input","value":"Text Input","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"placeholder","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"help","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","label":"Mini","selected":false},{"value":"input-small","label":"Small","selected":false},{"value":"input-medium","label":"Medium","selected":false},{"value":"input-large","label":"Large","selected":false},{"value":"input-xlarge","label":"Xlarge","selected":true},{"value":"input-xxlarge","label":"Xxlarge","selected":false}],"name":"inputsize"}}}]','<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>new form</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Text Input</label>
  <div class="controls">
    <input id="textinput" name="textinput" type="text" placeholder="placeholder" class="input-xlarge">
    <p class="help-block">help</p>
  </div>
</div>

</fieldset>
</form>
','list','','2014-04-10 05:19:07','2014-04-10 05:19:07');

-- --------------------------------------------------------
INSERT INTO built_forms (`id`,`name`,`category`,`description`,`data`,`rendered`,`redirect_to`,`extra_code`,`created_at`,`updated_at`) VALUES ('16','Form Namesads','1','','[{"title":"Form Name","fields":{"name":{"label":"Form Name","type":"input","value":"Form Namesads","name":"name"}}},{"title":"Text Input Multi 2","fields":{"id":{"label":"Input 1 ID / Name","type":"input","value":"input1id","name":"id"},"label":{"label":"Label Text","type":"input","value":"Text Input Multi","name":"label"},"input1label":{"label":"Label Text","type":"input","value":"Multi Text Input","name":"input1label"},"input1placeholder":{"label":"Placeholder","type":"input","value":"input1","name":"input1placeholder"},"input1required":{"label":"Required","type":"checkbox","value":false,"name":"input1required"},"input1inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","label":"Mini","selected":false},{"value":"input-small","label":"Small","selected":false},{"value":"input-medium","label":"Medium","selected":false},{"value":"input-large","label":"Large","selected":false},{"value":"input-xlarge","label":"Xlarge","selected":true},{"value":"input-xxlarge","label":"Xxlarge","selected":false}],"name":"input1inputsize"},"id2":{"label":"Input 3 ID / Name","type":"input","value":"input2id","name":"id2"},"input2label":{"label":"Label Text","type":"input","value":"Multi Text Input","name":"input2label"},"input2placeholder":{"label":"Placeholder","type":"input","value":"input2","name":"input2placeholder"},"input2required":{"label":"Required","type":"checkbox","value":false,"name":"input2required"},"input2inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","label":"Mini","selected":false},{"value":"input-small","label":"Small","selected":false},{"value":"input-medium","label":"Medium","selected":false},{"value":"input-large","label":"Large","selected":false},{"value":"input-xlarge","label":"Xlarge","selected":true},{"value":"input-xxlarge","label":"Xxlarge","selected":false}],"name":"input2inputsize"},"id3":{"label":"Input 2 ID / Name","type":"input","value":"input3id","name":"id3"},"input3label":{"label":"Label Text","type":"input","value":"Multi Text Input","name":"input3label"},"input3placeholder":{"label":"Placeholder","type":"input","value":"input3","name":"input3placeholder"},"input3required":{"label":"Required","type":"checkbox","value":false,"name":"input3required"},"input3inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","label":"Mini","selected":false},{"value":"input-small","label":"Small","selected":false},{"value":"input-medium","label":"Medium","selected":false},{"value":"input-large","label":"Large","selected":false},{"value":"input-xlarge","label":"Xlarge","selected":true},{"value":"input-xxlarge","label":"Xxlarge","selected":false}],"name":"input3inputsize"}}}]','<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Form Namesads</legend>

<!-- Text input-->

<div class="control-group">
  <label class="control-label" for="input1id">Text Input Multi</label>
  <div class="controls controls-row">

<input id="input1id" name="input1id" placeholder="input1" class="input-xlarge span3" type="text">


<input id="input2id" name="input2id" placeholder="input2" class="input-xlarge span3" type="text">

<input id="input3id" name="input3id" placeholder="input3" class="input-xlarge span3" type="text">

  </div>
</div>


</fieldset>
</form>
','list','','2014-04-10 07:14:08','2014-04-10 07:14:08');

-- --------------------------------------------------------
INSERT INTO built_forms (`id`,`name`,`category`,`description`,`data`,`rendered`,`redirect_to`,`extra_code`,`created_at`,`updated_at`) VALUES ('12','Form Testing','1','','[{"title":"Form Name","fields":{"name":{"label":"Form Name","type":"input","value":"Form Testing","name":"name"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinputasdfasdf","name":"id"},"label":{"label":"Label Text","type":"input","value":"Name","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Select Basic","fields":{"id":{"label":"ID / Name","type":"input","value":"selectbasic","name":"id"},"label":{"label":"Label Text","type":"input","value":"Country","name":"label"},"options":{"label":"Options","type":"textarea-split","value":["Option one","Option two"],"name":"options"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Area","fields":{"id":{"label":"ID / Name","type":"input","value":"textareaasdfasdf","name":"id"},"label":{"label":"Label Text","type":"input","value":"Address","name":"label"},"textarea":{"label":"Starting Text","type":"textarea","value":"","name":"textarea"}}}]','<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Form Testing</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinputasdfasdf">Name</label>
  <div class="controls">
    <input id="textinputasdfasdf" name="textinputasdfasdf" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="selectbasic">Country</label>
  <div class="controls">
    <select id="selectbasic" name="selectbasic" class="input-xlarge">
      <option>Option one</option>
      <option>Option two</option>
    </select>
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textareaasdfasdf">Address</label>
  <div class="controls">                     
    <textarea id="textareaasdfasdf" name="textareaasdfasdf"></textarea>
  </div>
</div>

</fieldset>
</form>
','list','','2014-04-09 08:18:52','2014-04-10 17:48:58');

-- --------------------------------------------------------
INSERT INTO built_forms (`id`,`name`,`category`,`description`,`data`,`rendered`,`redirect_to`,`extra_code`,`created_at`,`updated_at`) VALUES ('13','Test test test','1','','[{"title":"Form Name","fields":{"name":{"label":"Form Name","type":"input","value":"Test test test","name":"name"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinputasdfasdfasdf","name":"id"},"label":{"label":"Label Text","type":"input","value":"Test Test","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Area","fields":{"id":{"label":"ID / Name","type":"input","value":"textareaasdfasdf44","name":"id"},"label":{"label":"Label Text","type":"input","value":"Test Address","name":"label"},"textarea":{"label":"Starting Text","type":"textarea","value":"","name":"textarea"}}},{"title":"Single Button","fields":{"id":{"label":"ID / Name","type":"input","value":"singlebuttonasdfasdf","name":"id"},"label":{"label":"Label Text","type":"input","value":"","name":"label"},"buttonlabel":{"label":"Button Label","type":"input","value":"Submit","name":"buttonlabel"},"buttontype":{"label":"Button Type","type":"select","value":[{"value":"btn-default","selected":false,"label":"Default"},{"value":"btn-primary","selected":true,"label":"Primary"},{"value":"btn-info","selected":false,"label":"Info"},{"value":"btn-success","selected":false,"label":"Success"},{"value":"btn-warning","selected":false,"label":"Warning"},{"value":"btn-danger","selected":false,"label":"Danger"},{"value":"btn-inverse","selected":false,"label":"Inverse"}],"name":"buttontype"}}}]','<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Test test test</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinputasdfasdfasdf">Test Test</label>
  <div class="controls">
    <input id="textinputasdfasdfasdf" name="textinputasdfasdfasdf" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textareaasdfasdf44">Test Address</label>
  <div class="controls">                     
    <textarea id="textareaasdfasdf44" name="textareaasdfasdf44"></textarea>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebuttonasdfasdf"></label>
  <div class="controls">
    <button id="singlebuttonasdfasdf" name="singlebuttonasdfasdf" class="btn btn-primary">Submit</button>
  </div>
</div>

</fieldset>
</form>
','list','','2014-04-10 04:53:16','2014-04-10 04:53:16');

-- --------------------------------------------------------
INSERT INTO built_forms (`id`,`name`,`category`,`description`,`data`,`rendered`,`redirect_to`,`extra_code`,`created_at`,`updated_at`) VALUES ('14','My test','1','','[{"title":"Form Name","fields":{"name":{"label":"Form Name","type":"input","value":"My test","name":"name"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinputasfasdf23342","name":"id"},"label":{"label":"Label Text","type":"input","value":"Name","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Area","fields":{"id":{"label":"ID / Name","type":"input","value":"textareaasfa12312","name":"id"},"label":{"label":"Label Text","type":"input","value":"address","name":"label"},"textarea":{"label":"Starting Text","type":"textarea","value":"","name":"textarea"}}}]','<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>My test</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinputasfasdf23342">Name</label>
  <div class="controls">
    <input id="textinputasfasdf23342" name="textinputasfasdf23342" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textareaasfa12312">address</label>
  <div class="controls">                     
    <textarea id="textareaasfa12312" name="textareaasfa12312"></textarea>
  </div>
</div>

</fieldset>
</form>
','list','','2014-04-10 05:17:41','2014-04-10 05:17:41');

-- --------------------------------------------------------
INSERT INTO built_forms (`id`,`name`,`category`,`description`,`data`,`rendered`,`redirect_to`,`extra_code`,`created_at`,`updated_at`) VALUES ('9','Form one','1','','[{"title":"Form Name","fields":{"name":{"label":"Form Name","type":"input","value":"Form one","name":"name"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinputasdf345vv","name":"id"},"label":{"label":"Label Text","type":"input","value":"Name","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":true,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Area","fields":{"id":{"label":"ID / Name","type":"input","value":"textareasdfs324","name":"id"},"label":{"label":"Label Text","type":"input","value":"Adderss","name":"label"},"textarea":{"label":"Starting Text","type":"textarea","value":"","name":"textarea"}}},{"title":"Single Button","fields":{"id":{"label":"ID / Name","type":"input","value":"singlebuttonasdfasdf","name":"id"},"label":{"label":"Label Text","type":"input","value":"","name":"label"},"buttonlabel":{"label":"Button Label","type":"input","value":"Submit","name":"buttonlabel"},"buttontype":{"label":"Button Type","type":"select","value":[{"value":"btn-default","selected":false,"label":"Default"},{"value":"btn-primary","selected":true,"label":"Primary"},{"value":"btn-info","selected":false,"label":"Info"},{"value":"btn-success","selected":false,"label":"Success"},{"value":"btn-warning","selected":false,"label":"Warning"},{"value":"btn-danger","selected":false,"label":"Danger"},{"value":"btn-inverse","selected":false,"label":"Inverse"}],"name":"buttontype"}}}]','<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Form one</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinputasdf345vv">Name</label>
  <div class="controls">
    <input id="textinputasdf345vv" name="textinputasdf345vv" type="text" placeholder="" class="input-xlarge" required="">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textareasdfs324">Adderss</label>
  <div class="controls">                     
    <textarea id="textareasdfs324" name="textareasdfs324"></textarea>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebuttonasdfasdf"></label>
  <div class="controls">
    <button id="singlebuttonasdfasdf" name="singlebuttonasdfasdf" class="btn btn-primary">Submit</button>
  </div>
</div>

</fieldset>
</form>
','list','','2014-04-07 02:49:53','2014-04-07 02:49:53');

-- --------------------------------------------------------
INSERT INTO built_forms (`id`,`name`,`category`,`description`,`data`,`rendered`,`redirect_to`,`extra_code`,`created_at`,`updated_at`) VALUES ('10','Form two','1','','[{"title":"Form Name","fields":{"name":{"label":"Form Name","type":"input","value":"Form two","name":"name"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinputasdfasdf234","name":"id"},"label":{"label":"Label Text","type":"input","value":"Phone","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":true,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinputasdf12312","name":"id"},"label":{"label":"Label Text","type":"input","value":"Mobile","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":true,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Single Button","fields":{"id":{"label":"ID / Name","type":"input","value":"singlebuttonasdf","name":"id"},"label":{"label":"Label Text","type":"input","value":"","name":"label"},"buttonlabel":{"label":"Button Label","type":"input","value":"Submit","name":"buttonlabel"},"buttontype":{"label":"Button Type","type":"select","value":[{"value":"btn-default","selected":false,"label":"Default"},{"value":"btn-primary","selected":true,"label":"Primary"},{"value":"btn-info","selected":false,"label":"Info"},{"value":"btn-success","selected":false,"label":"Success"},{"value":"btn-warning","selected":false,"label":"Warning"},{"value":"btn-danger","selected":false,"label":"Danger"},{"value":"btn-inverse","selected":false,"label":"Inverse"}],"name":"buttontype"}}}]','<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Form two</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinputasdfasdf234">Phone</label>
  <div class="controls">
    <input id="textinputasdfasdf234" name="textinputasdfasdf234" type="text" placeholder="" class="input-xlarge" required="">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinputasdf12312">Mobile</label>
  <div class="controls">
    <input id="textinputasdf12312" name="textinputasdf12312" type="text" placeholder="" class="input-xlarge" required="">
    
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebuttonasdf"></label>
  <div class="controls">
    <button id="singlebuttonasdf" name="singlebuttonasdf" class="btn btn-primary">Submit</button>
  </div>
</div>

</fieldset>
</form>
','list','','2014-04-07 02:50:59','2014-04-07 02:50:59');

-- --------------------------------------------------------
INSERT INTO built_forms (`id`,`name`,`category`,`description`,`data`,`rendered`,`redirect_to`,`extra_code`,`created_at`,`updated_at`) VALUES ('11','test zero','1','','[{"title":"Form Name","fields":{"name":{"label":"Form Name","type":"input","value":"test zero","name":"name"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinput343c","name":"id"},"label":{"label":"Label Text","type":"input","value":"Name","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":true,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinputasdf11","name":"id"},"label":{"label":"Label Text","type":"input","value":"Phone","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"textinputasdfrr","name":"id"},"label":{"label":"Label Text","type":"input","value":"Email","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Area","fields":{"id":{"label":"ID / Name","type":"input","value":"textareaasdf33x","name":"id"},"label":{"label":"Label Text","type":"input","value":"Address","name":"label"},"textarea":{"label":"Starting Text","type":"textarea","value":"","name":"textarea"}}},{"title":"Single Button","fields":{"id":{"label":"ID / Name","type":"input","value":"singlebutton234","name":"id"},"label":{"label":"Label Text","type":"input","value":"","name":"label"},"buttonlabel":{"label":"Button Label","type":"input","value":"Submit","name":"buttonlabel"},"buttontype":{"label":"Button Type","type":"select","value":[{"value":"btn-default","selected":false,"label":"Default"},{"value":"btn-primary","selected":true,"label":"Primary"},{"value":"btn-info","selected":false,"label":"Info"},{"value":"btn-success","selected":false,"label":"Success"},{"value":"btn-warning","selected":false,"label":"Warning"},{"value":"btn-danger","selected":false,"label":"Danger"},{"value":"btn-inverse","selected":false,"label":"Inverse"}],"name":"buttontype"}}}]','<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>test zero</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput343c">Name</label>
  <div class="controls">
    <input id="textinput343c" name="textinput343c" type="text" placeholder="" class="input-xlarge" required="">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinputasdf11">Phone</label>
  <div class="controls">
    <input id="textinputasdf11" name="textinputasdf11" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinputasdfrr">Email</label>
  <div class="controls">
    <input id="textinputasdfrr" name="textinputasdfrr" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textareaasdf33x">Address</label>
  <div class="controls">                     
    <textarea id="textareaasdf33x" name="textareaasdf33x"></textarea>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebutton234"></label>
  <div class="controls">
    <button id="singlebutton234" name="singlebutton234" class="btn btn-primary">Submit</button>
  </div>
</div>

</fieldset>
</form>
','list','','2014-04-08 04:16:07','2014-04-08 04:16:07');

-- --------------------------------------------------------
INSERT INTO built_forms (`id`,`name`,`category`,`description`,`data`,`rendered`,`redirect_to`,`extra_code`,`created_at`,`updated_at`) VALUES ('8','Client Data','1','','[{"title":"Form Name","fields":{"name":{"label":"Form Name","type":"input","value":"Client Data","name":"name"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"client32nn","name":"id"},"label":{"label":"Label Text","type":"input","value":"Client Name","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Area","fields":{"id":{"label":"ID / Name","type":"input","value":"clientaddress9mm","name":"id"},"label":{"label":"Label Text","type":"input","value":"Address","name":"label"},"textarea":{"label":"Starting Text","type":"textarea","value":"","name":"textarea"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"phone8089","name":"id"},"label":{"label":"Label Text","type":"input","value":"Phone","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"email232","name":"id"},"label":{"label":"Label Text","type":"input","value":"Email ","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Text Input","fields":{"id":{"label":"ID / Name","type":"input","value":"website9808","name":"id"},"label":{"label":"Label Text","type":"input","value":"Website","name":"label"},"placeholder":{"label":"Placeholder","type":"input","value":"","name":"placeholder"},"helptext":{"label":"Help Text","type":"input","value":"","name":"helptext"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Select Basic","fields":{"id":{"label":"ID / Name","type":"input","value":"country009ms","name":"id"},"label":{"label":"Label Text","type":"input","value":"Country","name":"label"},"options":{"label":"Options","type":"textarea-split","value":["Bangladesh","Malaysia","Singapore","USA","Canada","Australia","UK","Japan"],"name":"options"},"inputsize":{"label":"Input Size","type":"select","value":[{"value":"input-mini","selected":false,"label":"Mini"},{"value":"input-small","selected":false,"label":"Small"},{"value":"input-medium","selected":false,"label":"Medium"},{"value":"input-large","selected":false,"label":"Large"},{"value":"input-xlarge","selected":true,"label":"Xlarge"},{"value":"input-xxlarge","selected":false,"label":"Xxlarge"}],"name":"inputsize"}}},{"title":"Multiple Radios","fields":{"name":{"label":"Group Name","type":"input","value":"status98nm","name":"name"},"label":{"label":"Label Text","type":"input","value":"Status","name":"label"},"required":{"label":"Required","type":"checkbox","value":false,"name":"required"},"radios":{"label":"Radios","type":"textarea-split","value":["Active","Inactive"],"name":"radios"}}},{"title":"Single Button","fields":{"id":{"label":"ID / Name","type":"input","value":"singlebutton44d","name":"id"},"label":{"label":"Label Text","type":"input","value":"","name":"label"},"buttonlabel":{"label":"Button Label","type":"input","value":"Submit","name":"buttonlabel"},"buttontype":{"label":"Button Type","type":"select","value":[{"value":"btn-default","selected":false,"label":"Default"},{"value":"btn-primary","selected":true,"label":"Primary"},{"value":"btn-info","selected":false,"label":"Info"},{"value":"btn-success","selected":false,"label":"Success"},{"value":"btn-warning","selected":false,"label":"Warning"},{"value":"btn-danger","selected":false,"label":"Danger"},{"value":"btn-inverse","selected":false,"label":"Inverse"}],"name":"buttontype"}}}]','<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Client Data</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="client32nn">Client Name</label>
  <div class="controls">
    <input id="client32nn" name="client32nn" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="clientaddress9mm">Address</label>
  <div class="controls">                     
    <textarea id="clientaddress9mm" name="clientaddress9mm"></textarea>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="phone8089">Phone</label>
  <div class="controls">
    <input id="phone8089" name="phone8089" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="email232">Email </label>
  <div class="controls">
    <input id="email232" name="email232" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="website9808">Website</label>
  <div class="controls">
    <input id="website9808" name="website9808" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="country009ms">Country</label>
  <div class="controls">
    <select id="country009ms" name="country009ms" class="input-xlarge">
      <option>Bangladesh</option>
      <option>Malaysia</option>
      <option>Singapore</option>
      <option>USA</option>
      <option>Canada</option>
      <option>Australia</option>
      <option>UK</option>
      <option>Japan</option>
    </select>
  </div>
</div>

<!-- Multiple Radios -->
<div class="control-group">
  <label class="control-label" for="status98nm">Status</label>
  <div class="controls">
    <label class="radio" for="status98nm-0">
      <input type="radio" name="status98nm" id="status98nm-0" value="Active" checked="checked">
      Active
    </label>
    <label class="radio" for="status98nm-1">
      <input type="radio" name="status98nm" id="status98nm-1" value="Inactive">
      Inactive
    </label>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebutton44d"></label>
  <div class="controls">
    <button id="singlebutton44d" name="singlebutton44d" class="btn btn-primary">Submit</button>
  </div>
</div>

</fieldset>
</form>
','list','','2014-03-28 07:33:25','2014-03-28 07:33:25');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'built_modules'
--

DROP TABLE IF EXISTS built_modules;
-- --------------------------------------------------------

CREATE TABLE `built_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `form_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `table_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `built_modules`
--

INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('9','Test zero','1','Admin','','','11','admin, backend','/home/tngbdcom/public_html/cms/app/storage/temp/test_zero.zip','test_zero','2014-04-08 04:16:46','2014-04-08 04:16:46');

-- --------------------------------------------------------
INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('8','Forms','1','Admin','','','9, 10','admin, backend','/home/tngbdcom/public_html/cms/app/storage/temp/forms.zip','form_s','2014-04-07 02:51:38','2014-04-07 02:51:38');

-- --------------------------------------------------------
INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('3','Test Module','1','Andrew','http://www.doptor.org','','8, 0','admin','/home/tngbdcom/public_html/cms/app/storage/temp/test_module.zip','testing_form','2014-03-22 08:35:16','2014-04-05 17:24:24');

-- --------------------------------------------------------
INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('13','Testing ','1','Admin','','','15','admin','/home/tngbdcom/public_html/cms/app/storage/temp/testing.zip','dsfsdf','2014-04-10 05:37:35','2014-04-10 05:37:35');

-- --------------------------------------------------------
INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('10','Form Testing','1','Test Admin','','','12, 9, 10','admin, backend','/home/tngbdcom/public_html/cms/app/storage/temp/form_testing.zip','form_testing','2014-04-09 08:20:01','2014-04-09 08:20:01');

-- --------------------------------------------------------
INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('11','Accounting','1','Admin','','','12, 9','admin','/home/tngbdcom/public_html/cms/app/storage/temp/accounting.zip','dsfsdf','2014-04-10 02:08:58','2014-04-10 02:08:58');

-- --------------------------------------------------------
INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('12','Test Test Test','1','Admin','','','13','admin','/home/tngbdcom/public_html/cms/app/storage/temp/test_test_test.zip','test_test','2014-04-10 04:54:17','2014-04-10 04:54:17');

-- --------------------------------------------------------
INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('14','Templates Affinity','1','Admin','','','17, 16','admin','/home/tngbdcom/public_html/cms/app/storage/temp/templates_affinity.zip','rana','2014-04-10 10:26:43','2014-04-10 10:26:43');

-- --------------------------------------------------------
INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('15','rana','1','Admin','','','9, 10, 12','admin','/home/tngbdcom/public_html/cms/app/storage/temp/rana.zip','rana','2014-04-10 10:28:14','2014-04-10 10:28:14');

-- --------------------------------------------------------
INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('16','Test','4','eer','','','17, 16, 15','admin','/home/tngbdcom/public_html/cms/app/storage/temp/test.zip','rt','2014-04-11 04:19:46','2014-04-11 04:19:46');

-- --------------------------------------------------------
INSERT INTO built_modules (`id`,`name`,`version`,`author`,`website`,`description`,`form_id`,`target`,`file`,`table_name`,`created_at`,`updated_at`) VALUES ('17','Accoun','1','Admin','','','9, 10','admin, backend','/home/tngbdcom/public_html/cms/app/storage/temp/accoun.zip','rana','2014-04-11 05:48:06','2014-04-11 05:48:06');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'categories'
--

DROP TABLE IF EXISTS categories;
-- --------------------------------------------------------

CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `language_id` int(10) unsigned NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'published',
  `created_by` int(10) unsigned NOT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `categories_language_id_index` (`language_id`),
  KEY `categories_created_by_index` (`created_by`),
  KEY `categories_updated_by_index` (`updated_by`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `categories`
--

INSERT INTO categories (`id`,`name`,`alias`,`type`,`language_id`,`description`,`status`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('2','First Category','first-category','post','1','Lorem Ipsum','published','1','','2014-03-30 00:00:00','2014-03-30 00:00:00');

-- --------------------------------------------------------
INSERT INTO categories (`id`,`name`,`alias`,`type`,`language_id`,`description`,`status`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('3','Another Category','another-category','page','1','Lorem Ipsum','published','1','','2014-03-30 00:00:00','2014-03-30 00:00:00');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'category_post'
--

DROP TABLE IF EXISTS category_post;
-- --------------------------------------------------------

CREATE TABLE `category_post` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_post_category_id_index` (`category_id`),
  KEY `category_post_post_id_index` (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `category_post`
--

INSERT INTO category_post (`id`,`category_id`,`post_id`) VALUES ('1','1','1');

-- --------------------------------------------------------
INSERT INTO category_post (`id`,`category_id`,`post_id`) VALUES ('2','1','2');

-- --------------------------------------------------------
INSERT INTO category_post (`id`,`category_id`,`post_id`) VALUES ('3','1','3');

-- --------------------------------------------------------
INSERT INTO category_post (`id`,`category_id`,`post_id`) VALUES ('4','1','4');

-- --------------------------------------------------------
INSERT INTO category_post (`id`,`category_id`,`post_id`) VALUES ('5','1','5');

-- --------------------------------------------------------
INSERT INTO category_post (`id`,`category_id`,`post_id`) VALUES ('6','1','7');

-- --------------------------------------------------------
INSERT INTO category_post (`id`,`category_id`,`post_id`) VALUES ('7','1','8');

-- --------------------------------------------------------
INSERT INTO category_post (`id`,`category_id`,`post_id`) VALUES ('8','3','13');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'form_categories'
--

DROP TABLE IF EXISTS form_categories;
-- --------------------------------------------------------

CREATE TABLE `form_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `form_categories`
--

INSERT INTO form_categories (`id`,`name`,`description`,`created_at`,`updated_at`) VALUES ('1','test','test','2014-03-21 05:10:03','2014-03-21 05:10:03');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'group_menu'
--

DROP TABLE IF EXISTS group_menu;
-- --------------------------------------------------------

CREATE TABLE `group_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `menu_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_menu_group_id_index` (`group_id`),
  KEY `group_menu_menu_id_index` (`menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `group_menu`
--

INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('2','2','11');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('3','1','11');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('4','1','33');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('5','2','33');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('6','1','37');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('7','1','38');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('8','1','39');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('9','1','40');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('10','1','46');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('11','1','47');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('12','1','48');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('13','1','49');

-- --------------------------------------------------------
INSERT INTO group_menu (`id`,`group_id`,`menu_id`) VALUES ('14','1','50');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'groups'
--

DROP TABLE IF EXISTS groups;
-- --------------------------------------------------------

CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `groups`
--

INSERT INTO groups (`id`,`name`,`permissions`,`created_at`,`updated_at`) VALUES ('1','Super Administrators','{"superuser":1}','2014-03-21 03:55:35','2014-03-21 03:55:35');

-- --------------------------------------------------------
INSERT INTO groups (`id`,`name`,`permissions`,`created_at`,`updated_at`) VALUES ('2','Users','{"modules.form23.index":1,"modules.form23.show":1,"modules.form23.create":1,"modules.form23.edit":1,"modules.form23.destroy":1}','2014-03-23 06:37:35','2014-03-28 02:10:04');

-- --------------------------------------------------------
INSERT INTO groups (`id`,`name`,`permissions`,`created_at`,`updated_at`) VALUES ('4','afV#@w345','{"superuser":1}','2014-03-25 15:51:29','2014-03-25 15:51:29');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'languages'
--

DROP TABLE IF EXISTS languages;
-- --------------------------------------------------------

CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `languages`
--

INSERT INTO languages (`id`,`name`,`created_at`,`updated_at`) VALUES ('2','English','2014-03-30 00:00:00','2014-03-30 00:00:00');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'media_entries'
--

DROP TABLE IF EXISTS media_entries;
-- --------------------------------------------------------

CREATE TABLE `media_entries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `caption` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `album_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `media_entries_created_by_index` (`created_by`),
  KEY `media_entries_updated_by_index` (`updated_by`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `media_entries`
--

INSERT INTO media_entries (`id`,`caption`,`image`,`thumbnail`,`album_id`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('1','','time line11_ihA2koJj.jpg','time line11_ihA2koJj.jpg','0','1','0','2014-03-21 04:14:09','2014-03-21 04:14:09');

-- --------------------------------------------------------
INSERT INTO media_entries (`id`,`caption`,`image`,`thumbnail`,`album_id`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('3','','Doptor Logo_UdhdA20E.png','Doptor Logo_UdhdA20E.png','0','3','0','2014-03-23 05:47:53','2014-03-23 05:47:53');

-- --------------------------------------------------------
INSERT INTO media_entries (`id`,`caption`,`image`,`thumbnail`,`album_id`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('8','','doptor/Doptor Logo Black_M6Cxwm5B.png','doptor/thumbs/Doptor Logo Black_M6Cxwm5B.png','','14','','2014-03-31 12:22:29','2014-03-31 12:22:29');

-- --------------------------------------------------------
INSERT INTO media_entries (`id`,`caption`,`image`,`thumbnail`,`album_id`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('9','','uploads/media/spritemap_Tjt9GGGK.png','uploads/media/thumbs/spritemap_Tjt9GGGK.png','','13','','2014-04-03 18:00:59','2014-04-03 18:00:59');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'menu_categories'
--

DROP TABLE IF EXISTS menu_categories;
-- --------------------------------------------------------

CREATE TABLE `menu_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `menu_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `menu_categories`
--

INSERT INTO menu_categories (`id`,`name`,`menu_type`,`description`,`created_at`,`updated_at`) VALUES ('3','Admin Top Menu','admin-top-menu','','2014-03-21 17:29:15','2014-03-21 17:29:15');

-- --------------------------------------------------------
INSERT INTO menu_categories (`id`,`name`,`menu_type`,`description`,`created_at`,`updated_at`) VALUES ('4','Admin Main Menu','admin-main-menu','','2014-03-22 03:58:49','2014-03-22 03:58:49');

-- --------------------------------------------------------
INSERT INTO menu_categories (`id`,`name`,`menu_type`,`description`,`created_at`,`updated_at`) VALUES ('5','Public Top Menu','public-top-menu','Public Top Menu','2014-03-22 11:10:47','2014-03-22 11:10:47');

-- --------------------------------------------------------
INSERT INTO menu_categories (`id`,`name`,`menu_type`,`description`,`created_at`,`updated_at`) VALUES ('6','Public Header Left','public-small-menu-left','Public Header Left','2014-03-22 11:18:36','2014-03-22 11:18:36');

-- --------------------------------------------------------
INSERT INTO menu_categories (`id`,`name`,`menu_type`,`description`,`created_at`,`updated_at`) VALUES ('7','Public Header Right','public-small-menu-right','Public Header Right','2014-03-22 11:18:50','2014-03-22 11:18:50');

-- --------------------------------------------------------
INSERT INTO menu_categories (`id`,`name`,`menu_type`,`description`,`created_at`,`updated_at`) VALUES ('8','Public Footer Left','public-bottom-menu','Public Footer Left','2014-03-22 11:19:16','2014-03-22 11:19:16');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'menus'
--

DROP TABLE IF EXISTS menus;
-- --------------------------------------------------------

CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_manual` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` int(10) unsigned NOT NULL,
  `display_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `same_window` tinyint(1) NOT NULL DEFAULT '1',
  `show_image` tinyint(1) NOT NULL DEFAULT '1',
  `is_wrapper` tinyint(1) NOT NULL DEFAULT '0',
  `wrapper_width` int(10) unsigned DEFAULT NULL,
  `wrapper_height` int(10) unsigned DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'published',
  `parent` int(10) unsigned NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `target` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language_id` int(10) unsigned NOT NULL,
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `menus_category_index` (`category`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `menus`
--

INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('4','Home','public-top-menu-home','/','','','5','Welcome to Doptor CMS.','1','1','0','','','published','0','1','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-22 11:11:17','2014-03-27 10:36:31');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('5','About Us','public-top-menu-about-us','pages/about-us','','#','5','','1','0','0','','','published','0','3','public','0','','','','','','2014-03-22 11:11:55','2014-03-31 12:30:19');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('6','Backend','public-small-menu-right-backend','manual','','backend','7','','0','1','0','','','published','0','1','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-22 11:20:05','2014-03-22 11:20:05');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('7','Admin','public-small-menu-right-admin','manual','','admin','7','','0','1','0','','','published','0','2','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-22 11:20:37','2014-03-22 11:20:37');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('8','About Us','public-bottom-menu-about-us','pages/about-us','','','8','','1','1','0','','','published','0','0','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-22 11:21:12','2014-03-22 11:21:12');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('9','Demo','public-small-menu-left-demo','pages/demo','','#','6','','0','0','0','','','published','0','1','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-22 11:22:01','2014-03-27 18:00:05');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('10','Download','public-small-menu-left-download','pages/under-construction','','','6','','0','0','0','','','published','0','2','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-22 11:22:25','2014-03-26 02:01:04');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('13','Contact Us','public-top-menu-contact-us','link_type/modules/form23','','','5','','1','1','0','','','unpublished','0','8','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-23 05:35:43','2014-03-26 15:20:22');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('14','Main','public-top-menu-main','manual','','#','5','','1','1','0','','','published','0','2','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-23 06:06:11','2014-03-23 06:13:58');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('15','Sub-1','public-top-menu-sub-1','manual','','#','5','','1','1','0','','','published','14','0','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-23 06:06:57','2014-03-23 06:06:57');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('16','Sub-2','public-top-menu-sub-2','manual','','#','5','','1','1','0','','','published','14','0','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-23 06:07:57','2014-03-23 06:09:26');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('17','Sub-3','public-top-menu-sub-3','manual','','#','5','','1','1','0','','','published','14','0','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-23 06:08:31','2014-03-23 06:10:12');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('18','Sub-Sub-1','public-top-menu-sub-sub-1','manual','','#','5','','1','1','0','','','published','15','0','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-23 06:11:29','2014-03-23 06:11:29');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('19','Sub-Sub-2','public-top-menu-sub-sub-2','manual','','#','5','','1','1','0','','','published','15','0','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-23 06:12:24','2014-03-23 06:12:24');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('20','Sub-Sub-Sub-1','public-top-menu-sub-sub-sub-1','manual','','#','5','','1','1','0','','','published','18','0','public','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','','','2014-03-23 06:13:15','2014-03-23 06:13:15');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('41','Acc category','admin-main-menu-acc-category','link_type/modules/add_account_category','time line11.jpg','','4','1','1','1','0','','','published','0','0','admin','0','','','','','','2014-04-05 11:12:50','2014-04-05 11:12:50');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('42','Acc Add','admin-main-menu-acc-add','link_type/modules/add_account','','','4','','1','1','0','','','published','0','2','admin','0','','','','','','2014-04-05 11:13:24','2014-04-05 11:13:24');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('43','Acc Balance','admin-main-menu-acc-balance','link_type/modules/account_balances','','','4','','1','1','0','','','published','0','0','admin','0','','','','','','2014-04-05 11:14:10','2014-04-05 11:14:10');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('32','Help','public-top-menu-help','pages/help','','','5','','1','0','0','','','published','0','10','public','0','','','','','','2014-03-28 05:50:17','2014-03-31 12:29:11');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('39','Test','admin-main-menu-test','manual','','#','4','','1','1','0','','','published','0','0','admin','0','','','','','','2014-04-04 03:20:39','2014-04-04 03:20:39');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('40','Test Sub','admin-main-menu-test-sub','manual','','#','4','','1','1','0','','','published','39','0','admin','0','','','','','','2014-04-04 03:21:42','2014-04-04 03:21:42');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('45','Forms','admin-main-menu-forms','link_type/modules/forms','','','4','','1','1','0','0','0','published','0','0','admin','0','','','','','','2014-04-07 02:52:47','2014-04-07 02:52:47');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('46','Test Zero','admin-main-menu-test-zero','link_type/modules/test_zero','','','4','','1','1','0','0','0','published','0','0','admin','0','','','','','','2014-04-08 04:17:57','2014-04-08 04:17:57');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('47','Form Testing','admin-main-menu-form-testing','link_type/modules/form_testing','','','4','','1','1','0','0','0','published','0','0','admin','0','','','','','','2014-04-09 08:20:57','2014-04-09 08:20:57');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('48','Accounting t','admin-main-menu-accounting-t','link_type/modules/accounting','','','4','','1','1','0','0','0','published','0','0','admin','0','','','','','','2014-04-10 02:10:33','2014-04-10 02:10:33');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('49','sub sub test','admin-main-menu-sub-sub-test','link_type/modules/billing_module','','','4','','1','1','0','0','0','published','47','0','admin','0','','','','','','2014-04-10 06:58:25','2014-04-10 06:58:25');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('50','rana','admin-main-menu-rana','link_type/modules/rana','','','4','','1','1','0','0','0','published','0','0','admin','0','','','','','','2014-04-10 10:29:26','2014-04-10 10:29:26');

-- --------------------------------------------------------
INSERT INTO menus (`id`,`title`,`alias`,`link`,`icon`,`link_manual`,`category`,`display_text`,`same_window`,`show_image`,`is_wrapper`,`wrapper_width`,`wrapper_height`,`status`,`parent`,`order`,`target`,`language_id`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`created_at`,`updated_at`) VALUES ('51','testing ','public-top-menu-testing','pages/abc-testing','','','5','','1','1','0','0','0','published','0','0','public','0','','','','','','2014-04-11 04:58:11','2014-04-11 04:58:11');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'migrations'
--

DROP TABLE IF EXISTS migrations;
-- --------------------------------------------------------

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `migrations`
--

INSERT INTO migrations (`migration`,`batch`) VALUES ('2012_12_06_225921_migration_cartalyst_sentry_install_users','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2012_12_06_225929_migration_cartalyst_sentry_install_groups','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2012_12_06_225945_migration_cartalyst_sentry_install_users_groups_pivot','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2012_12_06_225988_migration_cartalyst_sentry_install_throttle','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2013_12_05_152937_create_form_categories_table','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2013_12_14_150939_create_built_forms_table','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2013_12_16_085835_create_menucategories_table','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2013_12_16_142732_create_menus_table','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2013_12_26_144014_create_modules_table','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2014_02_02_104111_pivot_group_menu_table','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2014_02_04_061701_create_built_modules_table','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2014_02_14_030526_create_settings_table','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2014_02_19_175006_create_slideshow_table','1');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2014_01_26_155006_create_languages_table','2');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2014_01_26_175006_create_posts_table','2');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2014_01_28_153951_create_categories_table','2');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2014_01_29_063050_pivot_category_post_table','2');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2014_03_10_020526_create_media_entries_table','3');

-- --------------------------------------------------------
INSERT INTO migrations (`migration`,`batch`) VALUES ('2014_03_12_074541_create_themes_table','4');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'module_account_balances'
--

DROP TABLE IF EXISTS module_account_balances;
-- --------------------------------------------------------

CREATE TABLE `module_account_balances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `total_debit` text COLLATE utf8_unicode_ci,
  `total_credit` text COLLATE utf8_unicode_ci,
  `total_balance` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_account_balances`
--





-- --------------------------------------------------------
-- Structure for 'module_add_account'
--

DROP TABLE IF EXISTS module_add_account;
-- --------------------------------------------------------

CREATE TABLE `module_add_account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_name` text COLLATE utf8_unicode_ci,
  `account_database_table_name` text COLLATE utf8_unicode_ci,
  `account_type` text COLLATE utf8_unicode_ci,
  `account_category` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_add_account`
--





-- --------------------------------------------------------
-- Structure for 'module_add_account_category'
--

DROP TABLE IF EXISTS module_add_account_category;
-- --------------------------------------------------------

CREATE TABLE `module_add_account_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` text COLLATE utf8_unicode_ci,
  `status` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_add_account_category`
--





-- --------------------------------------------------------
-- Structure for 'module_billing'
--

DROP TABLE IF EXISTS module_billing;
-- --------------------------------------------------------

CREATE TABLE `module_billing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bill_number` text COLLATE utf8_unicode_ci,
  `vendor` text COLLATE utf8_unicode_ci,
  `created_date` text COLLATE utf8_unicode_ci,
  `due_date` text COLLATE utf8_unicode_ci,
  `notes` text COLLATE utf8_unicode_ci,
  `item` text COLLATE utf8_unicode_ci,
  `expense_account` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `quantity` text COLLATE utf8_unicode_ci,
  `price` text COLLATE utf8_unicode_ci,
  `amount` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_billing`
--

INSERT INTO module_billing (`id`,`bill_number`,`vendor`,`created_date`,`due_date`,`notes`,`item`,`expense_account`,`description`,`quantity`,`price`,`amount`,`created_at`,`updated_at`) VALUES ('1','423','Kuala','234','324','','','','','','','','2014-04-10 06:59:42','2014-04-10 06:59:42');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'module_doptor_invoice'
--

DROP TABLE IF EXISTS module_doptor_invoice;
-- --------------------------------------------------------

CREATE TABLE `module_doptor_invoice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_name` text COLLATE utf8_unicode_ci,
  `created_date` text COLLATE utf8_unicode_ci,
  `due_date` text COLLATE utf8_unicode_ci,
  `product_name` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `quantity` text COLLATE utf8_unicode_ci,
  `price` text COLLATE utf8_unicode_ci,
  `amount` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_doptor_invoice`
--





-- --------------------------------------------------------
-- Structure for 'module_dsfsdf'
--

DROP TABLE IF EXISTS module_dsfsdf;
-- --------------------------------------------------------

CREATE TABLE `module_dsfsdf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `textinputasdfasdf` text COLLATE utf8_unicode_ci,
  `textareaasdfasdf` text COLLATE utf8_unicode_ci,
  `textinputasdf345vv` text COLLATE utf8_unicode_ci,
  `textareasdfs324` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_dsfsdf`
--





-- --------------------------------------------------------
-- Structure for 'module_form_s'
--

DROP TABLE IF EXISTS module_form_s;
-- --------------------------------------------------------

CREATE TABLE `module_form_s` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `textinputasdf345vv` text COLLATE utf8_unicode_ci,
  `textareasdfs324` text COLLATE utf8_unicode_ci,
  `textinputasdfasdf234` text COLLATE utf8_unicode_ci,
  `textinputasdf12312` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_form_s`
--





-- --------------------------------------------------------
-- Structure for 'module_form_testing'
--

DROP TABLE IF EXISTS module_form_testing;
-- --------------------------------------------------------

CREATE TABLE `module_form_testing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `textinputasdfasdf` text COLLATE utf8_unicode_ci,
  `textareaasdfasdf` text COLLATE utf8_unicode_ci,
  `textinputasdf345vv` text COLLATE utf8_unicode_ci,
  `textareasdfs324` text COLLATE utf8_unicode_ci,
  `textinputasdfasdf234` text COLLATE utf8_unicode_ci,
  `textinputasdf12312` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_form_testing`
--

INSERT INTO module_form_testing (`id`,`textinputasdfasdf`,`textareaasdfasdf`,`textinputasdf345vv`,`textareasdfs324`,`textinputasdfasdf234`,`textinputasdf12312`,`created_at`,`updated_at`) VALUES ('1','Test','KL','test111','bd','234234','2345234523','2014-04-10 06:53:11','2014-04-10 06:53:11');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'module_products_inventory'
--

DROP TABLE IF EXISTS module_products_inventory;
-- --------------------------------------------------------

CREATE TABLE `module_products_inventory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_name` text COLLATE utf8_unicode_ci,
  `product_description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_products_inventory`
--





-- --------------------------------------------------------
-- Structure for 'module_rana'
--

DROP TABLE IF EXISTS module_rana;
-- --------------------------------------------------------

CREATE TABLE `module_rana` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `textinputasdf345vv` text COLLATE utf8_unicode_ci,
  `textareasdfs324` text COLLATE utf8_unicode_ci,
  `textinputasdfasdf234` text COLLATE utf8_unicode_ci,
  `textinputasdf12312` text COLLATE utf8_unicode_ci,
  `textinputasdfasdf` text COLLATE utf8_unicode_ci,
  `selectbasic` text COLLATE utf8_unicode_ci,
  `textareaasdfasdf` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_rana`
--

INSERT INTO module_rana (`id`,`textinputasdf345vv`,`textareasdfs324`,`textinputasdfasdf234`,`textinputasdf12312`,`textinputasdfasdf`,`selectbasic`,`textareaasdfasdf`,`created_at`,`updated_at`) VALUES ('1','123','123','234','234','345','','345','2014-04-10 10:36:27','2014-04-10 10:36:27');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'module_test_test'
--

DROP TABLE IF EXISTS module_test_test;
-- --------------------------------------------------------

CREATE TABLE `module_test_test` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `textinputasdfasdfasdf` text COLLATE utf8_unicode_ci,
  `textareaasdfasdf44` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_test_test`
--





-- --------------------------------------------------------
-- Structure for 'module_test_zero'
--

DROP TABLE IF EXISTS module_test_zero;
-- --------------------------------------------------------

CREATE TABLE `module_test_zero` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `textinput343c` text COLLATE utf8_unicode_ci,
  `textinputasdf11` text COLLATE utf8_unicode_ci,
  `textinputasdfrr` text COLLATE utf8_unicode_ci,
  `textareaasdf33x` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_test_zero`
--

INSERT INTO module_test_zero (`id`,`textinput343c`,`textinputasdf11`,`textinputasdfrr`,`textareaasdf33x`,`created_at`,`updated_at`) VALUES ('1','4564','3453','34534','3435','2014-04-10 07:29:27','2014-04-10 07:29:27');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'module_testing_form'
--

DROP TABLE IF EXISTS module_testing_form;
-- --------------------------------------------------------

CREATE TABLE `module_testing_form` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client32nn` text COLLATE utf8_unicode_ci,
  `clientaddress9mm` text COLLATE utf8_unicode_ci,
  `phone8089` text COLLATE utf8_unicode_ci,
  `email232` text COLLATE utf8_unicode_ci,
  `website9808` text COLLATE utf8_unicode_ci,
  `country009ms` text COLLATE utf8_unicode_ci,
  `status98nm` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `module_testing_form`
--

INSERT INTO module_testing_form (`id`,`client32nn`,`clientaddress9mm`,`phone8089`,`email232`,`website9808`,`country009ms`,`status98nm`,`created_at`,`updated_at`) VALUES ('1','dasd','asdsa','asdsa','asdas','sads','Bangladesh','Active','2014-04-10 17:50:31','2014-04-10 17:50:31');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'modules'
--

DROP TABLE IF EXISTS modules;
-- --------------------------------------------------------

CREATE TABLE `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `table` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `target` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `modules`
--

INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('26','Test Test Test','test_test_test','test_test','1','Admin','','','admin','1','2014-04-10 04:54:50','2014-04-10 04:54:50');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('25','Accounting','accounting','dsfsdf','1','Admin','','','admin','1','2014-04-10 02:09:52','2014-04-10 02:09:52');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('24','Form Testing','form_testing','form_testing','1','Test Admin','','','admin|backend','1','2014-04-09 08:20:20','2014-04-09 08:20:20');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('23','Test zero','test_zero','test_zero','1','Admin','','','admin|backend','1','2014-04-08 04:17:05','2014-04-08 04:17:05');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('22','Forms','forms','form_s','1','Admin','','','admin|backend','1','2014-04-07 02:51:56','2014-04-07 02:51:56');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('21','Test Module','test_module','testing_form','1','Andrew','http://www.doptor.org','','admin','1','2014-04-05 17:25:20','2014-04-05 17:25:20');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('16','Add Account','add_account','add_account','0.1','Doptor','http://www.tngbd.com','','admin|backend','1','2014-04-05 10:07:02','2014-04-05 10:07:02');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('17','Add Account Category','add_account_category','add_account_category','0.1','Doptor','http://www.tngbd.com','','admin|backend','1','2014-04-05 10:07:18','2014-04-05 10:07:18');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('15','Account Balances','account_balances','account_balances','0.1','Doptor','http://www.tngbd.com','','admin|backend','1','2014-04-05 10:06:46','2014-04-05 10:06:46');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('10','Add Customer','add_customer','add_customer','0.1','Doptor','http://www.tngbd.com','','admin|backend','1','2014-03-24 15:25:44','2014-03-24 15:25:44');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('18','Billing Module','billing_module','billing','0.1','Doptor','http://www.tngbd.com','','admin|backend','1','2014-04-05 10:07:51','2014-04-05 10:07:51');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('19','Invoice','invoice','doptor_invoice','0.1','Doptor','http://www.tngbd.com','','admin|backend','1','2014-04-05 10:08:28','2014-04-05 10:08:28');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('20','Product Inventory','product_inventory','products_inventory','0.1','Doptor','http://www.tngbd.com','','admin|backend','1','2014-04-05 10:08:42','2014-04-05 10:08:42');

-- --------------------------------------------------------
INSERT INTO modules (`id`,`name`,`alias`,`table`,`version`,`author`,`website`,`description`,`target`,`enabled`,`created_at`,`updated_at`) VALUES ('27','Accoun','accoun','rana','1','Admin','','','admin|backend','1','2014-04-10 10:28:34','2014-04-11 05:48:45');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'posts'
--

DROP TABLE IF EXISTS posts;
-- --------------------------------------------------------

CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permalink` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'published',
  `target` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language_id` int(10) unsigned NOT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `hits` int(11) NOT NULL DEFAULT '0',
  `created_by` int(10) unsigned NOT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `posts_language_id_index` (`language_id`),
  KEY `posts_created_by_index` (`created_by`),
  KEY `posts_updated_by_index` (`updated_by`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `posts`
--

INSERT INTO posts (`id`,`title`,`permalink`,`image`,`content`,`status`,`target`,`language_id`,`featured`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`type`,`hits`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('9','Welcome','welcome','','<p>The CMS public section can now be viewed at {{ HTML::link(url('/'), url('/')) }}</p>

                    <p>The CMS admin can now be viewed at {{ HTML::link(url('admin'), url('admin')) }}</p>

                    <p>The CMS backend can now be viewed at {{ HTML::link(url('backend'), url('backend')) }}</p>','published','public','1','0','','','','','','page','0','1','','2014-03-30 00:00:00','2014-03-30 00:00:00');

-- --------------------------------------------------------
INSERT INTO posts (`id`,`title`,`permalink`,`image`,`content`,`status`,`target`,`language_id`,`featured`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`type`,`hits`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('10','About Us','about-us','','<p>Doptor is an Integrated and well-designed Content Management System (CMS) provides an end user with the tools to build and maintain a sustainable web presence. For a serious company, having a maintainable website is extremely important and the effectiveness of such a site depends on the ease of use and power of the backend CMS. There are many available CMS out there but they are too generalized to fit the needs of many companies.</p>

<p>Introducing the new CMS platform for businesses, which caters to their exact need without sacrificing the power and quality of a standard platform. Through this CMS, websites can be built that aims to serve as a learning and knowledge-sharing platform for the company and act as communication tool to disseminate information to the internal and external stakeholders. The website will be a tool for sharing public information and build rapport with the external stakeholders. It will be the main channel for the company to publish and share information on activities, lessons learnt from the project interventions, good practices and relevant research. In addition to having a CMS, a business needs other tools for regular operations as well. These other suites of applications run in the different departments of the company but together they ensure the moving forward of the company. In order to assist a company with all these needs, the CMS platform will include additional business modules, for example Invoicing, Bills, Accounting, Payroll, etc.</p>

<p>This CMS compliable with IOS and android, other mobile devices and with all browser.</p>

<p>- Doptor are provide a free opensource CMS.&nbsp;<br />
- Build your website and any kind of application using doptor.<br />
- Both online and offline.</p>

<p>3 type of interface- 1). Backend, 2). Admin, 3). Public</p>

<p>- Backend : You can manage full system.<br />
- Admin : Your officer / clark can do the operation such as accounting, payroll, inventory etc.<br />
- Public : &nbsp;Public website.</p>
','published','public','2','0','','','','','','page','12','1','14','2014-03-30 00:00:00','2014-04-08 17:05:59');

-- --------------------------------------------------------
INSERT INTO posts (`id`,`title`,`permalink`,`image`,`content`,`status`,`target`,`language_id`,`featured`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`type`,`hits`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('11','First Post','first-post','','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi odio mauris, auctor ut varius non, tempus nec nisi. Quisque at tellus risus. Aliquam erat volutpat. Proin et dolor magna. Sed vel metus justo. Mauris eu metus massa. Duis viverra ultricies nisl, ut pharetra eros hendrerit non.</p>
<p>Phasellus laoreet libero non eros rhoncus sed iaculis ante molestie. Etiam arcu purus, dictum a tincidunt id, ornare sed orci. Curabitur ornare ornare nulla quis tincidunt. Morbi nisi elit, mattis nec bibendum vel, facilisis eu ipsum. Phasellus non dolor erat, in placerat lacus. Aliquam pulvinar, est eu commodo vulputate, neque elit molestie lorem, sed vestibulum felis erat et risus. Nulla non velit odio.</p>
<p>Curabitur ornare ornare nulla quis tincidunt. Morbi nisi elit, mattis nec bibendum vel, facilisis eu ipsum. Phasellus non dolor erat, in placerat lacus. Aliquam pulvinar, est eu commodo vulputate, neque elit molestie lorem, sed vestibulum felis erat et risus. Nulla non velit odio.</p>','published','public','1','0','','','','','','post','0','1','','2014-03-30 00:00:00','2014-03-30 00:00:00');

-- --------------------------------------------------------
INSERT INTO posts (`id`,`title`,`permalink`,`image`,`content`,`status`,`target`,`language_id`,`featured`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`type`,`hits`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('12','Second Post','second-post','','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi odio mauris, auctor ut varius non, tempus nec nisi. Quisque at tellus risus. Aliquam erat volutpat. Proin et dolor magna. Sed vel metus justo. Mauris eu metus massa. Duis viverra ultricies nisl, ut pharetra eros hendrerit non.</p>
<p>Phasellus laoreet libero non eros rhoncus sed iaculis ante molestie. Etiam arcu purus, dictum a tincidunt id, ornare sed orci. Curabitur ornare ornare nulla quis tincidunt. Morbi nisi elit, mattis nec bibendum vel, facilisis eu ipsum. Phasellus non dolor erat, in placerat lacus. Aliquam pulvinar, est eu commodo vulputate, neque elit molestie lorem, sed vestibulum felis erat et risus. Nulla non velit odio.</p>
<p>Curabitur ornare ornare nulla quis tincidunt. Morbi nisi elit, mattis nec bibendum vel, facilisis eu ipsum. Phasellus non dolor erat, in placerat lacus. Aliquam pulvinar, est eu commodo vulputate, neque elit molestie lorem, sed vestibulum felis erat et risus. Nulla non velit odio.</p>','published','public','1','0','','','','','','post','0','1','','2014-03-30 00:00:00','2014-03-30 00:00:00');

-- --------------------------------------------------------
INSERT INTO posts (`id`,`title`,`permalink`,`image`,`content`,`status`,`target`,`language_id`,`featured`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`type`,`hits`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('13','Help','help','','<p>How to create accounting module :&nbsp;<br />
4 steps for create any kind of module such as accounting, payroll, inventory etc. (we are keepon increase controller for form builder). Now 5%-10% programming (coding) required. Coming soon 0% coding.<br />
&nbsp;<br />
Step -1 : Create one or two form (Builder--&gt;Form Builder), all field name must be unique.&nbsp;<br />
Step -2 : Create a module (Builder --&gt; Module Builder) and select which form you are using.&nbsp;<br />
Step -3 : Install Module. go to Extension --&gt; module --&gt; Install<br />
Step -4 : Create Menu (Menu manager) must assign module.<br />
&nbsp;<br />
Thanks<br />
And Enjoy.</p>

<p>&nbsp;</p>
','published','public','2','0','','','','','','page','6','14','','0000-00-00 00:00:00','2014-04-07 02:55:33');

-- --------------------------------------------------------
INSERT INTO posts (`id`,`title`,`permalink`,`image`,`content`,`status`,`target`,`language_id`,`featured`,`publish_start`,`publish_end`,`meta_title`,`meta_description`,`meta_keywords`,`type`,`hits`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('14','abc testing','abc-testing','','<p>abc testingabc testingabc testingabc testingabc testing</p>

<p>abc testingabc testingabc testingabc testingabc testing</p>

<p>abc testingabc testingabc testingabc testingabc testing</p>

<p>abc testingabc testingabc testingabc testingabc testing</p>
','published','public','0','0','','','','','','page','3','15','','0000-00-00 00:00:00','2014-04-11 04:59:22');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'settings'
--

DROP TABLE IF EXISTS settings;
-- --------------------------------------------------------

CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `settings`
--

INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('1','website_name','','Doptor CMS','2014-03-22 11:17:11','2014-03-31 12:20:08');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('2','footer_text','','Powered by : Doptor v1.2, Copyright @ 2011-2014','2014-03-22 11:17:11','2014-03-25 09:36:38');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('3','public_offline','','no','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('4','public_offline_end','','','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('5','admin_offline','','no','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('6','admin_offline_end','','','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('7','backend_offline','','no','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('8','backend_offline_end','','','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('9','offline_message','','','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('10','email_host','','','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('11','email_port','','','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('12','email_encryption','','false','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('13','email_username','','','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('14','email_password','','','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('15','mysqldump_path','','','2014-03-22 11:17:11','2014-03-22 11:17:11');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('16','backend_theme','','3','2014-03-31 12:20:08','2014-03-31 12:20:08');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('17','admin_theme','','2','2014-03-31 12:20:08','2014-03-31 12:20:08');

-- --------------------------------------------------------
INSERT INTO settings (`id`,`name`,`description`,`value`,`created_at`,`updated_at`) VALUES ('18','public_theme','','1','2014-03-31 12:20:08','2014-03-31 12:20:08');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'slideshow'
--

DROP TABLE IF EXISTS slideshow;
-- --------------------------------------------------------

CREATE TABLE `slideshow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `caption` text COLLATE utf8_unicode_ci,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'published',
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `slideshow_created_by_index` (`created_by`),
  KEY `slideshow_updated_by_index` (`updated_by`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `slideshow`
--

INSERT INTO slideshow (`id`,`caption`,`image`,`status`,`publish_start`,`publish_end`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('5','<p>doptor</p>
','doptor profile 11.png','published','0000-00-00 00:00:00','0000-00-00 00:00:00','6','0','2014-03-26 15:17:28','2014-03-26 15:17:28');

-- --------------------------------------------------------
INSERT INTO slideshow (`id`,`caption`,`image`,`status`,`publish_start`,`publish_end`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('2','<p>www.doptor.org</p>
','doptor profile.png','published','0000-00-00 00:00:00','0000-00-00 00:00:00','3','1','2014-03-22 11:27:07','2014-03-23 04:59:35');

-- --------------------------------------------------------
INSERT INTO slideshow (`id`,`caption`,`image`,`status`,`publish_start`,`publish_end`,`created_by`,`updated_by`,`created_at`,`updated_at`) VALUES ('4','<p>DOPTOR</p>
','doptor_banner.png','published','0000-00-00 00:00:00','0000-00-00 00:00:00','6','0','2014-03-26 15:15:52','2014-03-26 15:15:52');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'themes'
--

DROP TABLE IF EXISTS themes;
-- --------------------------------------------------------

CREATE TABLE `themes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `screenshot` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `directory` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `themes_created_by_index` (`created_by`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `themes`
--

INSERT INTO themes (`id`,`name`,`version`,`author`,`description`,`screenshot`,`directory`,`target`,`created_by`,`created_at`,`updated_at`) VALUES ('1','Default Public Theme','1.0','','Default Public Theme','','default','public','1','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO themes (`id`,`name`,`version`,`author`,`description`,`screenshot`,`directory`,`target`,`created_by`,`created_at`,`updated_at`) VALUES ('2','Default Admin Theme','1.0','','Default Admin Theme','','default','admin','1','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO themes (`id`,`name`,`version`,`author`,`description`,`screenshot`,`directory`,`target`,`created_by`,`created_at`,`updated_at`) VALUES ('3','Default Backend Theme','1.0','','Default Backend Theme','','default','backend','1','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'throttle'
--

DROP TABLE IF EXISTS throttle;
-- --------------------------------------------------------

CREATE TABLE `throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `throttle_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `throttle`
--

INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('1','1','202.51.76.235','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('2','1','115.164.81.233','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('3','2','','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('4','3','','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('5','1','115.164.208.202','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('6','4','','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('7','2','::1','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('8','2','202.94.66.148','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('9','1','115.164.186.72','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('10','3','115.164.186.72','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('11','5','','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('12','6','115.164.186.72','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('13','3','115.164.176.234','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('14','3','175.139.238.167','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('15','2','103.9.114.162','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('16','7','180.149.7.240','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('17','8','','0','0','1','0000-00-00 00:00:00','0000-00-00 00:00:00','2014-03-25 09:30:32');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('18','12','113.199.251.143','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('19','9','','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('20','10','','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('21','11','','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('22','13','113.199.251.143','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('23','7','183.91.15.14','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('24','7','175.139.238.167','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('25','13','202.94.66.148','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('26','13','::1','0','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('27','6','115.164.50.166','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('28','7','115.164.50.166','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('29','14','115.164.50.166','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('30','5','115.164.50.166','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('31','14','175.139.238.167','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('32','14','115.164.216.170','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('33','13','103.242.216.234','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('34','13','113.199.222.14','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('35','7','115.164.93.177','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('36','7','115.164.54.104','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('37','7','115.164.55.221','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('38','1','110.44.117.82','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('39','7','103.242.216.234','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('40','7','141.0.15.9','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('41','7','115.164.212.185','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('42','15','175.139.238.167','0','0','0','','','');

-- --------------------------------------------------------
INSERT INTO throttle (`id`,`user_id`,`ip_address`,`attempts`,`suspended`,`banned`,`last_attempt_at`,`suspended_at`,`banned_at`) VALUES ('43','7','115.164.216.209','0','0','0','','','');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'users'
--

DROP TABLE IF EXISTS users;
-- --------------------------------------------------------

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `activation_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `persist_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_activation_code_index` (`activation_code`),
  KEY `users_reset_password_code_index` (`reset_password_code`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `users`
--

INSERT INTO users (`id`,`username`,`email`,`password`,`photo`,`permissions`,`activated`,`activation_code`,`activated_at`,`last_login`,`persist_code`,`reset_password_code`,`first_name`,`last_name`,`created_at`,`updated_at`) VALUES ('1','test','test@test.com','$2y$10$NR9ruYMgZsLiND7HGJccsejY8OHRGwhgBB8ezXiVBdeHhZ8qYe/bW','Doptor Logo Black.png','','1','','0000-00-00 00:00:00','2014-04-11 04:17:29','$2y$10$N8Xnhf7QY9HdD8ybGfZ4Rep5VAEIlzW.3FJX5GFmU1f3k9eNI66eS','','test','test','2014-03-21 03:55:35','2014-04-11 04:17:29');

-- --------------------------------------------------------
INSERT INTO users (`id`,`username`,`email`,`password`,`photo`,`permissions`,`activated`,`activation_code`,`activated_at`,`last_login`,`persist_code`,`reset_password_code`,`first_name`,`last_name`,`created_at`,`updated_at`) VALUES ('5','andrew','outsource79@gmail.com','$2y$10$TA2Fkn5iwNv.ckxFy9Q1Muyoh9RoE2rknOraHDCH0e5UkWmI10yoK','','','1','','0000-00-00 00:00:00','2014-03-28 05:52:56','$2y$10$2ZA8UNb7Eyb/0sWcAqgY2eBHXAtkrF3KKCW2aA/rHm6igCS4Kfjpu','','Andres','Hew','2014-03-23 06:33:21','2014-03-28 05:52:56');

-- --------------------------------------------------------
INSERT INTO users (`id`,`username`,`email`,`password`,`photo`,`permissions`,`activated`,`activation_code`,`activated_at`,`last_login`,`persist_code`,`reset_password_code`,`first_name`,`last_name`,`created_at`,`updated_at`) VALUES ('6','user','useradsf@asdfdsf.com','$2y$10$Ae8OxuVTZ8jGDEpEgIz0buxFtgWAT2cvl33GbG5lNO1YK3BnPFOGu','time line11.jpg','','1','','0000-00-00 00:00:00','2014-03-28 05:47:36','$2y$10$WCZEY7nynrWqrahozVn2yezDTNu2KNUg2x3rMs.RrmO60qrQGhp0.','','User','user','2014-03-23 06:38:55','2014-03-28 05:47:36');

-- --------------------------------------------------------
INSERT INTO users (`id`,`username`,`email`,`password`,`photo`,`permissions`,`activated`,`activation_code`,`activated_at`,`last_login`,`persist_code`,`reset_password_code`,`first_name`,`last_name`,`created_at`,`updated_at`) VALUES ('7','demo','demo@adeasdf.com','$2y$10$zH5fLSYUWSnGgiqrc9/cau.XyUd9610QrpqqdgvF/A.5nBq51bGWG','time line11.jpg','','1','','0000-00-00 00:00:00','2014-04-11 14:08:11','$2y$10$rAghbtlcEz2SqAPeKs9cs.kFLLZhhp6WzMpMojmaGzR4BIU.BZoCS','','demo','demo','2014-03-25 09:13:36','2014-04-11 14:08:11');

-- --------------------------------------------------------
INSERT INTO users (`id`,`username`,`email`,`password`,`photo`,`permissions`,`activated`,`activation_code`,`activated_at`,`last_login`,`persist_code`,`reset_password_code`,`first_name`,`last_name`,`created_at`,`updated_at`) VALUES ('9','riyadh','ra@gnn.com','$2y$10$WqTQWr5tR2v.dqkNDwwCnOw//bIv/atE4IBint0r6uUwzy3O/QwPa','','','1','','0000-00-00 00:00:00','0000-00-00 00:00:00','','','gss','grgg','2014-03-25 09:33:45','2014-03-25 09:33:45');

-- --------------------------------------------------------
INSERT INTO users (`id`,`username`,`email`,`password`,`photo`,`permissions`,`activated`,`activation_code`,`activated_at`,`last_login`,`persist_code`,`reset_password_code`,`first_name`,`last_name`,`created_at`,`updated_at`) VALUES ('13','superadmin','admin@asd.com','$2y$10$vZzfQO1/PrXh2J5TEzyS1.4VN6xeKoQT3MU8YuBeW1h5K0aaJLPei','','','1','','0000-00-00 00:00:00','2014-04-11 18:27:51','$2y$10$dzAke1snj7CxvTL0ktY0POt7Tu26O0cW64PGiQfNCimaVEEtRiaCW','','Super','Admin','2014-03-25 11:06:51','2014-04-11 18:27:51');

-- --------------------------------------------------------
INSERT INTO users (`id`,`username`,`email`,`password`,`photo`,`permissions`,`activated`,`activation_code`,`activated_at`,`last_login`,`persist_code`,`reset_password_code`,`first_name`,`last_name`,`created_at`,`updated_at`) VALUES ('14','doptor','info@doptor.org','$2y$10$knBpt2y2iCOA5Rx4Ue0vo.KuZggE10fnsjxU8IwrqNoGHCmemiBV.','','','1','','','2014-03-31 09:57:17','$2y$10$NueAdYfQhT9RLMEJRDql1OhQPNAOJhWKVLzX/.0YtvqgkcjPwgKES','','Doptor','Doptor','2014-03-28 02:34:24','2014-03-31 12:38:32');

-- --------------------------------------------------------




-- --------------------------------------------------------
-- Structure for 'users_groups'
--

DROP TABLE IF EXISTS users_groups;
-- --------------------------------------------------------

CREATE TABLE `users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------
-- Dump Data for `users_groups`
--

INSERT INTO users_groups (`user_id`,`group_id`) VALUES ('1','1');

-- --------------------------------------------------------
INSERT INTO users_groups (`user_id`,`group_id`) VALUES ('5','1');

-- --------------------------------------------------------
INSERT INTO users_groups (`user_id`,`group_id`) VALUES ('6','2');

-- --------------------------------------------------------
INSERT INTO users_groups (`user_id`,`group_id`) VALUES ('7','1');

-- --------------------------------------------------------
INSERT INTO users_groups (`user_id`,`group_id`) VALUES ('9','1');

-- --------------------------------------------------------
INSERT INTO users_groups (`user_id`,`group_id`) VALUES ('13','1');

-- --------------------------------------------------------
INSERT INTO users_groups (`user_id`,`group_id`) VALUES ('14','1');

-- --------------------------------------------------------



