<?php
/*
=================================================
Module Name     :   TestMultiForm
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   www.doptor.org
Description     :   
===================================================
*/
class ModuleTestmultiform extends Eloquent {

	protected $table = 'module_multi_form';

	protected $fillable = array('name212','country334','address_12','radios','name_113','description',);
	protected $guarded = array();


}
