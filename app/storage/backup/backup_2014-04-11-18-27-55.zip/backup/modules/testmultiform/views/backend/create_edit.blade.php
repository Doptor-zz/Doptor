@extends('backend.default._layouts._layout')

@section('content')
    <div class="row-fluid">
        <div class="span12">
            <!-- BEGIN FORM widget-->
            <div class="widget box blue tabbable">
                <div class="widget-title">
                    <h4>
                        <span>{{ $title }}</span>
                        &nbsp;
                    </h4>
                </div>
                <div class="widget-body form">
                    <div class="tab-pane active" id="widget_tab1">
                        <!-- BEGIN FORM-->
                        <ul class="nav nav-tabs"><li class="active"><a href="#tab_1_0" data-toggle="tab">Test11</a></li><li class=""><a href="#tab_1_1" data-toggle="tab">Test9</a></li></ul><?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif
<div class="tab-content"><div class="tab-pane active" id="tab_1_0"><fieldset><!-- Form Name --><!-- Text input--><div class="control-group">  <label class="control-label" for="name212">Name</label>  <div class="controls">    <input id="name212" name="name212" type="text" placeholder="" class="input-xlarge" required="">      </div></div><!-- Select Basic --><div class="control-group">  <label class="control-label" for="country334">Country</label>  <div class="controls">    <select id="country334" name="country334" class="input-xlarge">      <option>BD</option>      <option>MY</option>      <option>SG</option>    </select>  </div></div><!-- Textarea --><div class="control-group">  <label class="control-label" for="address_12">Address</label>  <div class="controls">                         <textarea id="address_12" name="address_12"></textarea>  </div></div><!-- Multiple Radios --><div class="control-group">  <label class="control-label" for="radios">Status</label>  <div class="controls">    <label class="radio" for="radios-0">      <input type="radio" name="radios" id="radios-0" value="Active" checked="checked">      Active    </label>    <label class="radio" for="radios-1">      <input type="radio" name="radios" id="radios-1" value="InActive">      InActive    </label>  </div></div><!-- Button --><div class="control-group">  <label class="control-label" for="submit11"></label>  <div class="controls">    <button id="submit11" name="submit11" class="btn btn-primary">Submit</button>  </div></div></fieldset></div><div class="tab-pane " id="tab_1_1"><fieldset><!-- Form Name --><!-- Text input--><div class="control-group">  <label class="control-label" for="name_113">Religion</label>  <div class="controls">    <input id="name_113" name="name_113" type="text" placeholder="" class="input-xlarge">      </div></div><!-- Textarea --><div class="control-group">  <label class="control-label" for="description">Description</label>  <div class="controls">                         <textarea id="description" name="description"></textarea>  </div></div><!-- Button --><div class="control-group">  <label class="control-label" for="singlebutton118"></label>  <div class="controls">    <button id="singlebutton118" name="singlebutton118" class="btn btn-primary">Submit</button>  </div></div></fieldset></div></div><div class="form-actions">
                        <button type="submit" class="btn btn-primary" name="form_save">Save</button>

                        <button type="submit" class="btn btn-success" name="form_save_new">Save &amp; New</button>

                        <button type="submit" class="btn btn-primary btn-danger" name="form_close">Close</button>
                    </div>{{ Form::close() }}
                        <!-- END FORM-->
                        
                    </div>
                </div>
            </div>
            <!-- END FORM widget-->
        </div>
    </div>
@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
            jQuery(document).ready(function() {
                // While editing fields populate with its data
                @foreach ($fields as $field)
                    <?php
                        $entry->{$field} = preg_replace('~[\r\n]+~', ' ', $entry->{$field});
                        $entry->{$field} = str_replace('\n', " ", $entry->{$field}) ;
                    ?>
                    field = $('[name={{ $field }}]');
                    if (field.is('input[type=radio]')) {
                        field.filter('[value="{{ $entry->{$field} }}"]').attr('checked', true);
                        restore_uniformity();
                    } else {
                        field.val('{{ $entry->{$field} }}');
                    }
                @endforeach
            });
            function restore_uniformity() {
                $.uniform.restore("input[type=radio]");
                $('input[type=radio]').uniform();
            }
        </script>
    @endif
@stop
