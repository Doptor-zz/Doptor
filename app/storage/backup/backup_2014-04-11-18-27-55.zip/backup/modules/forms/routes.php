<?php
/*
=================================================
Module Name     :   Forms
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   
Description     :   
===================================================
*/
$current_dir = basename(__DIR__);
$current_module = "\\" . Str::title(basename(__DIR__));

// Backend routes
Route::resource('admin/modules/'.$current_dir, 'FormsBackendController');
Route::resource('backend/modules/'.$current_dir, 'FormsBackendController');

