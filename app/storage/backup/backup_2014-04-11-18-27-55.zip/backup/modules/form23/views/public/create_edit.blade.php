@section('content')

<section class="indent">
    <div class="container">
        <div class="accordion-wrapper grid_12">

            @if (Session::has('error_message'))
                <div class="grid_8">
                    <div class="alert alert-error nomargin">
                        Error! {{ Session::get('error_message') }}
                    </div>
                </div>
                <div class="clearfix"></div>
            @endif
            @if (Session::has('success_message'))
                <div class="grid_8">
                    <div class="alert alert-success nomargin">
                        Success! {{ Session::get('success_message') }}
                    </div>
                </div>
                <div class="clearfix"></div>
            @endif

            <h1>{{ $title }}</h1>

            <ul class="nav nav-tabs"><li class="active"><a href="#tab_1_0" data-toggle="tab">Form23</a></li></ul><?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif
<div class="tab-content"><div class="tab-pane active" id="tab_1_0">
<fieldset>

<!-- Form Name -->


<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput434jl">Name</label>
  <div class="controls">
    <input id="textinput434jl" name="textinput434jl" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="selectbasicjklj23">Country</label>
  <div class="controls">
    <select id="selectbasicjklj23" name="selectbasicjklj23" class="input-xlarge">
      <option>BD</option>
      <option>MY</option>
      <option>SG</option>
      <option>IND</option>
      <option>US</option>
    </select>
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea242sad">Address</label>
  <div class="controls">                     
    <textarea id="textarea242sad" name="textarea242sad"></textarea>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebutton221s"></label>
  <div class="controls">
    <button id="singlebutton221s" name="singlebutton221s" class="btn btn-primary">Submit</button>
  </div>
</div>

</fieldset>

</div></div><div class="form-actions">
                        <button type="submit" class="btn btn-primary" name="form_save">Save</button>

                        <button type="submit" class="btn btn-success" name="form_save_new">Save &amp; New</button>

                        <button type="submit" class="btn btn-primary btn-danger" name="form_close">Close</button>
                    </div>{{ Form::close() }}

            
        </div>
    </div>
</section>

@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
           jQuery(document).ready(function() {
                @foreach ($fields as $field)
                    $('#{{ $field }} ').val('{{ $entry->{$field} }}');
                @endforeach
           });
        </script>
    @endif
@stop
