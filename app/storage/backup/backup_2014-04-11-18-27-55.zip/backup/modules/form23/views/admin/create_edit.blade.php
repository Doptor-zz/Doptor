@section('content')
    <div class="row-fluid">
        <div class="span12">
            <!-- BEGIN FORM widget-->
            <div class="widget box tabbable">
                <div class="blue widget-title">
                    <h4>
                        <span>{{ $title }}</span>
                        &nbsp;
                    </h4>
                </div>
                <div class="widget-body form">
                    <div class="tab-widget">
                        <!-- BEGIN FORM-->
                        <ul class="nav nav-tabs"><li class="active"><a href="#tab_1_0" data-toggle="tab">Form23</a></li></ul><?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif
<div class="tab-content"><div class="tab-pane active" id="tab_1_0">
<fieldset>

<!-- Form Name -->


<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput434jl">Name</label>
  <div class="controls">
    <input id="textinput434jl" name="textinput434jl" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="selectbasicjklj23">Country</label>
  <div class="controls">
    <select id="selectbasicjklj23" name="selectbasicjklj23" class="input-xlarge">
      <option>BD</option>
      <option>MY</option>
      <option>SG</option>
      <option>IND</option>
      <option>US</option>
    </select>
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea242sad">Address</label>
  <div class="controls">                     
    <textarea id="textarea242sad" name="textarea242sad"></textarea>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebutton221s"></label>
  <div class="controls">
    <button id="singlebutton221s" name="singlebutton221s" class="btn btn-primary">Submit</button>
  </div>
</div>

</fieldset>

</div></div><div class="form-actions">
                        <button type="submit" class="btn btn-primary" name="form_save">Save</button>

                        <button type="submit" class="btn btn-success" name="form_save_new">Save &amp; New</button>

                        <button type="submit" class="btn btn-primary btn-danger" name="form_close">Close</button>
                    </div>{{ Form::close() }}
                        <!-- END FORM-->
                        
                    </div>
                </div>
            </div>
            <!-- END FORM widget-->
        </div>
    </div>
@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
           jQuery(document).ready(function() {
                // While editing fields populate with its data
                @foreach ($fields as $field)
                    <?php

                        $entry->{$field} = preg_replace('~[\r\n]+~', ' ', $entry->{$field});
                        $entry->{$field} = str_replace('\n', " ", $entry->{$field}) ;
                    ?>
                    field = $('[name={{ $field }}]');
                    if (field.is('input[type=radio]')) {
                        field.filter('[value="{{ $entry->{$field} }}"]').attr('checked', true);
                    } else {
                        field.val('{{ $entry->{$field} }}');
                    }
                @endforeach
           });
        </script>
    @endif
@stop
