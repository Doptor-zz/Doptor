<?php namespace App\Modules\Form23;
/*
=================================================
Module Name     :   Form23
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   http://www.doptor.org
Description     :   Test module.
===================================================
*/
class ServiceProvider extends \Illuminate\Support\ServiceProvider {

	public function register()
	{
		// Register facades
		$this->app->booting(function()
		{
			$loader = \Illuminate\Foundation\AliasLoader::getInstance();
			// $loader->alias('Entry', 'App\Modules\Content\Facades\EntryFacade');
		});
	}

}
