<?php
/*
=================================================
Module Name     :   Form23
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   http://www.doptor.org
Description     :   Test module.
===================================================
*/
class ModuleForm23 extends Eloquent {

	protected $table = 'module_form23';

	protected $fillable = array('textinput434jl','selectbasicjklj23','textarea242sad',);
	protected $guarded = array();


}
