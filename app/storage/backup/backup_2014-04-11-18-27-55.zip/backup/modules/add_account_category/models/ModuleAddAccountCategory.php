<?php

class ModuleAddAccountCategory extends Eloquent {

	protected $table = 'module_add_account_category';

	protected $fillable = array('category_name','status',);
	protected $guarded = array();


}
