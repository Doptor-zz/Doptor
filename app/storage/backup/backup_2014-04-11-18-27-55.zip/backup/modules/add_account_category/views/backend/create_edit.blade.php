@extends('backend.default._layouts._layout')

@section('content')
    <div class="row-fluid">
        <div class="span12">
            <!-- BEGIN FORM widget-->
            <div class="widget box blue tabbable">
                <div class="widget-title">
                    <h4>
                        <span>{{ $title }}</span>
                        &nbsp;
                    </h4>
                </div>
                <div class="widget-body form">
                    <div class="tabbable widget-tabs">
                        <div class="tab-content">
                            <div class="tab-pane active" id="widget_tab1">
                                <!-- BEGIN FORM-->
                                <?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif

<fieldset>

<!-- Form Name -->
<legend>Add Account Category</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="category_name">Category Name</label>
  <div class="controls">
    <input id="category_name" name="category_name" placeholder="Account Category Name" class="input-xlarge" type="text">
    <p class="help-block">Account Category Name</p>
  </div>
</div>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="status">Category Status</label>
  <div class="controls">
    <select id="status" name="status" class="input-xlarge">
      <option value="1">Active</option>
      <option value="0">Inactive</option>
    </select>
  </div>
</div>

  <button class="btn btn-success" type="submit">
                                    Add Account Category<i class="icon-plus"></i>
                                </button>

</fieldset>

{{ Form::close() }}
                                <!-- END FORM-->
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END FORM widget-->
        </div>
    </div>
@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
           jQuery(document).ready(function() {
                @foreach ($fields as $field)
                    $('#{{ $field }} ').val('{{ $entry->{$field} }}');
                @endforeach
           });
        </script>
    @endif
@stop
