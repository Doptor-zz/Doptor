<?php

class PostsTableSeeder extends \Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		DB::table('posts')->delete();

        $lorem = '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi odio mauris, auctor ut varius non, tempus nec nisi. Quisque at tellus risus. Aliquam erat volutpat. Proin et dolor magna. Sed vel metus justo. Mauris eu metus massa. Duis viverra ultricies nisl, ut pharetra eros hendrerit non.</p>
<p>Phasellus laoreet libero non eros rhoncus sed iaculis ante molestie. Etiam arcu purus, dictum a tincidunt id, ornare sed orci. Curabitur ornare ornare nulla quis tincidunt. Morbi nisi elit, mattis nec bibendum vel, facilisis eu ipsum. Phasellus non dolor erat, in placerat lacus. Aliquam pulvinar, est eu commodo vulputate, neque elit molestie lorem, sed vestibulum felis erat et risus. Nulla non velit odio.</p>
<p>Curabitur ornare ornare nulla quis tincidunt. Morbi nisi elit, mattis nec bibendum vel, facilisis eu ipsum. Phasellus non dolor erat, in placerat lacus. Aliquam pulvinar, est eu commodo vulputate, neque elit molestie lorem, sed vestibulum felis erat et risus. Nulla non velit odio.</p>';

		$posts = array(
            array(
                'title' => 'Welcome',
                'permalink' => 'welcome',
                'content' => "<p>The CMS public section can now be viewed at {{ HTML::link(url('/'), url('/')) }}</p>

                    <p>The CMS admin can now be viewed at {{ HTML::link(url('admin'), url('admin')) }}</p>

                    <p>The CMS backend can now be viewed at {{ HTML::link(url('backend'), url('backend')) }}</p>",
                'status' => 'published',
                'type' => 'page',
                'target' => 'public',
                'created_by' => 1,
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ),
            array(
                'title' => 'About Us',
                'permalink' => 'about-us',
                'content' => $lorem
,
                'status' => 'published',
                'type' => 'page',
                'target' => 'public',
                'created_by' => 1,
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ),
            array(
                'title' => 'First Post',
                'permalink' => 'first-post',
                'content' => $lorem
,
                'status' => 'published',
                'type' => 'post',
                'target' => 'public',
                'created_by' => 1,
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ),
            array(
                'title' => 'Second Post',
                'permalink' => 'second-post',
                'content' => $lorem
,
                'status' => 'published',
                'type' => 'post',
                'target' => 'public',
                'created_by' => 1,
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            )
		);

		// Uncomment the below to run the seeder
		DB::table('posts')->insert($posts);
	}

}
