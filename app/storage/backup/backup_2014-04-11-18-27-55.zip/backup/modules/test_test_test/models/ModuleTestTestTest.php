<?php
/*
=================================================
Module Name     :   Test Test Test
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   
Description     :   
===================================================
*/
class ModuleTestTestTest extends Eloquent {

	protected $table = 'module_test_test';

	protected $fillable = array('textinputasdfasdfasdf','textareaasdfasdf44',);
	protected $guarded = array();


}
