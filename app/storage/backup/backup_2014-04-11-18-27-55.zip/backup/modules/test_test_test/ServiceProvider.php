<?php namespace App\Modules\Test_Test_Test;
/*
=================================================
Module Name     :   Test Test Test
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   
Description     :   
===================================================
*/
class ServiceProvider extends \Illuminate\Support\ServiceProvider {

	public function register()
	{
		// Register facades
		$this->app->booting(function()
		{
			$loader = \Illuminate\Foundation\AliasLoader::getInstance();
			// $loader->alias('Entry', 'App\Modules\Content\Facades\EntryFacade');
		});
	}

}
