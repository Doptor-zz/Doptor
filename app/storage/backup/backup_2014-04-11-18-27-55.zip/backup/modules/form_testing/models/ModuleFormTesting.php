<?php
/*
=================================================
Module Name     :   Form Testing
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   
Description     :   
===================================================
*/
class ModuleFormTesting extends Eloquent {

	protected $table = 'module_form_testing';

	protected $fillable = array('textinputasdfasdf','textareaasdfasdf','textinputasdf345vv','textareasdfs324','textinputasdfasdf234','textinputasdf12312',);
	protected $guarded = array();


}
