<?php
/*
=================================================
Module Name     :   Test Module
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   http://www.doptor.org
Description     :   
===================================================
*/
class ModuleTestModule extends Eloquent {

	protected $table = 'module_testing_form';

	protected $fillable = array('client32nn','clientaddress9mm','phone8089','email232','website9808','country009ms','status98nm',);
	protected $guarded = array();


}
