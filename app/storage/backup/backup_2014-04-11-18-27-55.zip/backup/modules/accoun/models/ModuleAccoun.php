<?php
/*
=================================================
Module Name     :   Accoun
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   
Description     :   
===================================================
*/
class ModuleAccoun extends Eloquent {

	protected $table = 'module_rana';

	protected $fillable = array('textinputasdf345vv','textareasdfs324','textinputasdfasdf234','textinputasdf12312',);
	protected $guarded = array();


}
