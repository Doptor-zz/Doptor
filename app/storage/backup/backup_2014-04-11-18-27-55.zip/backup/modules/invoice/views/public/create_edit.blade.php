@section('content')

<section class="indent">
    <div class="container">
        <div class="accordion-wrapper grid_12">

            @if (Session::has('error_message'))
                <div class="grid_8">
                    <div class="alert alert-error nomargin">
                        Error! {{ Session::get('error_message') }}
                    </div>
                </div>
                <div class="clearfix"></div>
            @endif
            @if (Session::has('success_message'))
                <div class="grid_8">
                    <div class="alert alert-success nomargin">
                        Success! {{ Session::get('success_message') }}
                    </div>
                </div>
                <div class="clearfix"></div>
            @endif

            <h1>{{ $title }}</h1>

            <?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif

<fieldset>

<!-- Form Name -->
<legend>Invoice</legend>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="customer_name">Customer</label>
  <div class="controls">
    <select id="customer_name" name="customer_name" class="input-xlarge">
      <option>Option one</option>
    </select>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="created_date">Date</label>
  <div class="controls">
    <input id="created_date" name="created_date" placeholder="Date" class="input-xlarge" type="text">
    <p class="help-block">Date</p>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="due_date">Due Date</label>
  <div class="controls">
    <input id="due_date" name="due_date" placeholder="Due Date" class="input-xlarge" type="text">
    <p class="help-block">Due Date</p>
  </div>
</div>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="product_name">Product</label>
  <div class="controls">
    <select id="product_name" name="product_name" class="input-xlarge">
      <option>Option one</option>
      <option>Option two</option>
    </select>
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="description">Description</label>
  <div class="controls">                     
    <textarea id="description" name="description">Description</textarea>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="quantity">Quantity</label>
  <div class="controls">
    <input id="quantity" name="quantity" placeholder="Quantity" class="input-xlarge" type="text">
    <p class="help-block">Quantity</p>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="price">Price</label>
  <div class="controls">
    <input id="price" name="price" placeholder="Price" class="input-xlarge" type="text">
    <p class="help-block">Price</p>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="amount">Amount</label>
  <div class="controls">
    <input id="amount" name="amount" placeholder="Amount" class="input-xlarge" type="text">
    <p class="help-block">Amount</p>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="submit">Submit</label>
  <div class="controls">
    <button id="submit" name="submit" class="btn btn-primary">Submit</button>
  </div>
</div>

</fieldset>

{{ Form::close() }}

            
        </div>
    </div>
</section>

@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
           jQuery(document).ready(function() {
                @foreach ($fields as $field)
                    $('#{{ $field }} ').val('{{ $entry->{$field} }}');
                @endforeach
           });
        </script>
    @endif
@stop
