@extends('backend.default._layouts._layout')

@section('content')
    <div class="row-fluid">
        <div class="span12">
            <!-- BEGIN FORM widget-->
            <div class="widget box blue tabbable">
                <div class="widget-title">
                    <h4>
                        <span>{{ $title }}</span>
                        &nbsp;
                    </h4>
                </div>
                <div class="widget-body form">
                    <div class="tabbable widget-tabs">
                        <div class="tab-content">
                            <div class="tab-pane active" id="widget_tab1">
                                <!-- BEGIN FORM-->
                                <?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif

<fieldset>

<!-- Form Name -->
<legend>Invoice</legend>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="customer_name">Customer</label>
  <div class="controls">
    <select id="customer_name" name="customer_name" class="input-xlarge">
          <?php 
            $query = DB::table('module_add_customer')->select('module_add_customer.id', 'module_add_customer.customer_name');
            $customers = $query->get();
            $count = $query->count();
          ?>
        @if($count!=0)
          @foreach($customers as $customer)
            <option value="{{$customer->customer_name}}">{{$customer->customer_name}}</option>
          @endforeach
        @else
          <span style="color:#E52525;" >You must add at least one Customer first using the Customers Module first!</span>
        @endif
    </select>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="created_date">Date</label>
  <div class="controls">
    <input id="created_date" name="created_date" placeholder="Date" class="input-xlarge" type="text">
    <p class="help-block">Date</p>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="due_date">Due Date</label>
  <div class="controls">
    <input id="due_date" name="due_date" placeholder="Due Date" class="input-xlarge" type="text">
    <p class="help-block">Due Date</p>
  </div>
</div>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="product_name">Product</label>
  <div class="controls">
    <select id="product_name" name="product_name" class="input-xlarge">
        <?php 
          $query = DB::table('module_products_inventory')->select('module_products_inventory.id', 'module_products_inventory.product_name');
          $products = $query->get();
          $count = $query->count();
        ?>
      @if($count!=0)
        @foreach($products as $product)
          <option value="{{$product->product_name}}">{{$product->product_name}}</option>
        @endforeach
      @else
        <span style="color:#E52525;" >You must add Products using the Product Inventory Module first!</span>
      @endif
    </select>
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="description">Description</label>
  <div class="controls">                     
    <textarea id="description" name="description">Description</textarea>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="quantity">Quantity</label>
  <div class="controls">
    <input id="quantity" onchange="getTotalAmount()" name="quantity" placeholder="Quantity" class="input-xlarge" type="text">
    <p class="help-block">Quantity</p>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="price">Price</label>
  <div class="controls">
    <input id="price" name="price" onchange="getTotalAmount()" placeholder="Price" class="input-xlarge" type="text">
    <p class="help-block">Price</p>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="amount">Amount</label>
  <div class="controls">
    <input id="amount" name="amount" placeholder="Amount" class="input-xlarge" type="text">
    <p class="help-block">Amount</p>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="submit">Submit</label>
  <div class="controls">
    <button id="submit" type="submit" name="submit" class="btn btn-primary">Submit</button>
  </div>
</div>

</fieldset>

{{ Form::close() }}
                                <!-- END FORM-->
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END FORM widget-->
        </div>
    </div>




{{--Calculation --}}

<script>
    function getTotalAmount()
    {
        var quantity = document.getElementById('quantity').value;
        var price = document.getElementById('price').value;
        var total_amount = quantity * price;

        document.getElementById('amount').value = total_amount;

    }

</script>

@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
           jQuery(document).ready(function() {
                @foreach ($fields as $field)
                    $('#{{ $field }} ').val('{{ $entry->{$field} }}');
                @endforeach
           });
        </script>
    @endif
@stop
