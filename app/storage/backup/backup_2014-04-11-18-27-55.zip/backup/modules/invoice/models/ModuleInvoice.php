<?php

class ModuleInvoice extends Eloquent {

	protected $table = 'module_doptor_invoice';

	protected $fillable = array('customer_name','created_date','due_date','product_name','description','quantity','price','amount',);
	protected $guarded = array();


}
