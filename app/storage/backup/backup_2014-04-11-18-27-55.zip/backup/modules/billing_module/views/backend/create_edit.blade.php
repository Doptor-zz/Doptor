@extends('backend.default._layouts._layout')

@section('content')
    <div class="row-fluid">
        <div class="span12">
            <!-- BEGIN FORM widget-->
            <div class="widget box blue tabbable">
                <div class="widget-title">
                    <h4>
                        <span>{{ $title }}</span>
                        &nbsp;
                    </h4>
                </div>
                <div class="widget-body form">
                    <div class="tab-pane active" id="widget_tab1">
                        <!-- BEGIN FORM-->
                        <ul class="nav nav-tabs"><li class="active"><a href="#tab_1_0" data-toggle="tab">Billing Account</a></li><li class=""><a href="#tab_1_1" data-toggle="tab">Billing</a></li></ul><?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif
<div class="tab-content"><div class="tab-pane active" id="tab_1_0">
<fieldset>

<!-- Form Name -->


<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="bill_number">Bill Number</label>
  <div class="controls">
    <input id="bill_number" name="bill_number" placeholder="" class="input-xlarge" type="text">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="vendor">Vendor</label>
  <div class="controls">
    <input id="vendor" name="vendor" placeholder="" class="input-xlarge" type="text">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="created_date">Date</label>
  <div class="controls">
    <input id="created_date" name="created_date" placeholder="" class="input-xlarge" type="text">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="due_date">Due Date</label>
  <div class="controls">
    <input id="due_date" name="due_date" placeholder="" class="input-xlarge" type="text">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="notes">Notes</label>
  <div class="controls">                     
    <textarea id="notes" name="notes"></textarea>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="Save Account">Save Account</label>
  <div class="controls">
    <button id="Save Account" name="Save Account" class="btn btn-primary">Button</button>
  </div>
</div>

</fieldset>

</div><div class="tab-pane " id="tab_1_1">
<fieldset>

<!-- Form Name -->

<table class="table table-bordered" id="multiline">
  <tbody>
    <tr>
      <td>Item</td>
      <td>Expense Account</td>
      <td>Description</td>
      <td>Quantity</td>
      <td>Price</td>
      <td>Amount </td>
    </tr>

    <tr>
      <td>
        <select id="item" name="item" class="input-small">
            <?php 
              $query = DB::table('module_products_inventory')->select('module_products_inventory.id', 'module_products_inventory.product_name');
              $products = $query->get();
              $count = $query->count();
            ?>
          @if($count!=0)
            @foreach($products as $product)
              <option value="{{$product->product_name}}">{{$product->product_name}}</option>
            @endforeach
          @else
            <span style="color:#E52525;" >You must add Products using the Product Inventory Module first!</span>
          @endif
        </select>        
      </td>


      <td>
        <select id="expense_account" name="expense_account" class="input-small">
            <?php 
              $query = DB::table('module_add_account')->select('module_add_account.id', 'module_add_account.account_name');
              $accounts = $query->get();
              $count = $query->count();
            ?>
          @if($count!=0)
            @foreach($accounts as $account)
              <option value="{{$account->account_name}}">{{$account->account_name}}</option>
            @endforeach
          @else
            <span style="color:#E52525;" >You must add Expense Account using the Add Account Module first!</span>
          @endif
        </select>        
      </td>


      <td>
        <textarea id="description" name="description"></textarea>
      </td>


      <td>
        <input onchange="getTotalBalance()" id="quantity" name="quantity" placeholder="0" class="input-small" type="text">
      </td>


      <td>
         <input onchange="getTotalBalance()" id="price" name="price" placeholder="0" class="input-small" type="text">
      </td>


      <td>
        <input onchange="getTotalBalance()" id="amount" name="amount" placeholder="0" class="input-small" type="text">
      </td>


    </tr>    

    
    
  </tbody>

</table>

<a class="text-success" href="#" onclick="add_new_line();" ><i class="icon icon-plus-sign"></i> Add New Line </a>


<!-- Button -->
<div class="control-group">
  <label class="control-label" for="create_bill">Create Bill</label>
  <div class="controls">
    <button id="create_bill" name="create_bill" class="btn btn-success">Create Bill</button>
  </div>
</div>

</fieldset>

</div></div><div class="form-actions">
                        <button type="submit" class="btn btn-primary" name="form_save">Save</button>

                        <button type="submit" class="btn btn-success" name="form_save_new">Save &amp; New</button>

                        <button type="submit" class="btn btn-primary btn-danger" name="form_close">Close</button>
                    </div>
 


                      <script>

                          function add_new_line(){

                            var theDiv = document.getElementById("multiline");
                            theDiv.innerHTML += "<tr><td><select id='item' name='item' class='input-small'><?php $query = DB::table('module_products_inventory')->select('module_products_inventory.id', 'module_products_inventory.product_name');$products = $query->get();$count = $query->count();?>@if($count!=0)@foreach($products as $product)<option value='{{$product->product_name}}'>{{$product->product_name}}</option>@endforeach@else<span style='color:#E52525;' >You must add Products using the Product Inventory Module first!</span>@endif</select></td><td><select id='expense_account' name='expense_account' class='input-small'><?php $query = DB::table('module_add_account')->select('module_add_account.id', 'module_add_account.account_name');$accounts = $query->get();$count = $query->count();?>@if($count!=0)@foreach($accounts as $account)<option value='{{$account->account_name}}'>{{$account->account_name}}</option>@endforeach@else<span style='color:#E52525;' >You must add Expense Account using the Add Account Module first!</span>@endif</select></td><td><textarea id='description' name='description'></textarea></td><td><input onchange='getTotalBalance2()' id='quantity' name='quantity' placeholder='0' class='input-small' type='text'></td><td><input onchange='getTotalBalance2()' id='price' name='price' placeholder='0' class='input-small' type='text'></td><td><input onchange='getTotalBalance2()' id='amount' name='amount' placeholder='0' class='input-small' type='text'></td></tr>";                      
                          }


                          function getTotalBalance()
                          {
                              var quantity = document.getElementById('quantity').value;
                              var price = document.getElementById('price').value;
                              var total_amount = quantity * price;

                              document.getElementById('amount').value = total_amount;

                          }


                          function getTotalBalance2()
                          {
                              var quantity = document.getElementById('quantity').value;
                              var price = document.getElementById('price').value;
                              var total_amount = quantity * price;

                              document.getElementById('amount').value = total_amount;

                          }

                      </script>                                      



                    {{ Form::close() }}
                        <!-- END FORM-->
                        
                    </div>
                </div>
            </div>
            <!-- END FORM widget-->
        </div>
    </div>
@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
            jQuery(document).ready(function() {
                // While editing fields populate with its data
                @foreach ($fields as $field)
                    <?php
                        $entry->{$field} = preg_replace('~[\r\n]+~', ' ', $entry->{$field});
                        $entry->{$field} = str_replace('\n', " ", $entry->{$field}) ;
                    ?>
                    field = $('[name={{ $field }}]');
                    if (field.is('input[type=radio]')) {
                        field.filter('[value="{{ $entry->{$field} }}"]').attr('checked', true);
                        restore_uniformity();
                    } else {
                        field.val('{{ $entry->{$field} }}');
                    }
                @endforeach
            });
            function restore_uniformity() {
                $.uniform.restore("input[type=radio]");
                $('input[type=radio]').uniform();
            }
        </script>
    @endif
@stop
