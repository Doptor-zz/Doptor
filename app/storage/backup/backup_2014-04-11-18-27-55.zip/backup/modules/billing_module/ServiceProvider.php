<?php namespace App\Modules\Billing_Module;
/*
=================================================
Module Name     :   Billing Module
Module Version  :   v0.1
Compatible CMS  :   v1.2
Site            :   http://www.tngbd.com
Description     :   Billing module by doptor
===================================================
*/
class ServiceProvider extends \Illuminate\Support\ServiceProvider {

	public function register()
	{
		// Register facades
		$this->app->booting(function()
		{
			$loader = \Illuminate\Foundation\AliasLoader::getInstance();
			// $loader->alias('Entry', 'App\Modules\Content\Facades\EntryFacade');
		});
	}

}
