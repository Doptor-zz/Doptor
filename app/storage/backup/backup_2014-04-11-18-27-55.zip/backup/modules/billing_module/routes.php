<?php
/*
=================================================
Module Name     :   Billing Module
Module Version  :   v0.1
Compatible CMS  :   v1.2
Site            :   http://www.tngbd.com
Description     :   Billing module by doptor
===================================================
*/
$current_dir = basename(__DIR__);
$current_module = "\\" . Str::title(basename(__DIR__));

// Backend routes
Route::resource('admin/modules/'.$current_dir, 'BillingModuleBackendController');
Route::resource('backend/modules/'.$current_dir, 'BillingModuleBackendController');

