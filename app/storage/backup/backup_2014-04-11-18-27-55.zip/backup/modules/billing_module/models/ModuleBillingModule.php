<?php
/*
=================================================
Module Name     :   Billing Module
Module Version  :   v0.1
Compatible CMS  :   v1.2
Site            :   http://www.tngbd.com
Description     :   Billing module by doptor
===================================================
*/
class ModuleBillingModule extends Eloquent {

	protected $table = 'module_billing';

	protected $fillable = array('bill_number','vendor','created_date','due_date','notes','item','expense_account','description','quantity','price','amount',);
	protected $guarded = array();


}
