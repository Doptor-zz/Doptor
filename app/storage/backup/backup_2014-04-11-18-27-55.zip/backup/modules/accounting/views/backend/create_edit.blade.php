@extends('backend.default._layouts._layout')

@section('content')
    <div class="row-fluid">
        <div class="span12">
            <!-- BEGIN FORM widget-->
            <div class="widget box blue tabbable">
                <div class="widget-title">
                    <h4>
                        <span>{{ $title }}</span>
                        &nbsp;
                    </h4>
                </div>
                <div class="widget-body form">
                    <div class="tab-pane active" id="widget_tab1">
                        <!-- BEGIN FORM-->
                        <ul class="nav nav-tabs"><li class="active"><a href="#tab_1_0" data-toggle="tab">Form Testing</a></li><li class=""><a href="#tab_1_1" data-toggle="tab">Form one</a></li></ul><?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif
<div class="tab-content"><div class="tab-pane active" id="tab_1_0">
<fieldset>

<!-- Form Name -->


<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinputasdfasdf">Name</label>
  <div class="controls">
    <input id="textinputasdfasdf" name="textinputasdfasdf" type="text" placeholder="" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textareaasdfasdf">Address</label>
  <div class="controls">                     
    <textarea id="textareaasdfasdf" name="textareaasdfasdf"></textarea>
  </div>
</div>

</fieldset>

</div><div class="tab-pane " id="tab_1_1">
<fieldset>

<!-- Form Name -->


<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinputasdf345vv">Name</label>
  <div class="controls">
    <input id="textinputasdf345vv" name="textinputasdf345vv" type="text" placeholder="" class="input-xlarge" required="">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textareasdfs324">Adderss</label>
  <div class="controls">                     
    <textarea id="textareasdfs324" name="textareasdfs324"></textarea>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebuttonasdfasdf"></label>
  <div class="controls">
    <button id="singlebuttonasdfasdf" name="singlebuttonasdfasdf" class="btn btn-primary">Submit</button>
  </div>
</div>

</fieldset>

</div></div><div class="form-actions">
                        <button type="submit" class="btn btn-primary" name="form_save">Save</button>

                        <button type="submit" class="btn btn-success" name="form_save_new">Save &amp; New</button>

                        <button type="submit" class="btn btn-primary btn-danger" name="form_close">Close</button>
                    </div>{{ Form::close() }}
                        <!-- END FORM-->
                    </div>
                </div>
            </div>
            <!-- END FORM widget-->
        </div>
    </div>
@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
            jQuery(document).ready(function() {
                // While editing fields populate with its data
                @foreach ($fields as $field)
                    <?php
                        $entry->{$field} = preg_replace('~[\r\n]+~', ' ', $entry->{$field});
                        $entry->{$field} = str_replace('\n', " ", $entry->{$field}) ;
                    ?>
                    field = $('[name={{ $field }}]');
                    if (field.is('input[type=radio]')) {
                        field.filter('[value="{{ $entry->{$field} }}"]').attr('checked', true);
                        restore_uniformity();
                    } else {
                        field.val('{{ $entry->{$field} }}');
                    }
                @endforeach
            });
            function restore_uniformity() {
                $.uniform.restore("input[type=radio]");
                $('input[type=radio]').uniform();
            }
        </script>
    @endif

    
@stop
