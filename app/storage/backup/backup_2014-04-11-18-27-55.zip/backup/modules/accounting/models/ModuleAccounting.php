<?php
/*
=================================================
Module Name     :   Accounting
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   
Description     :   
===================================================
*/
class ModuleAccounting extends Eloquent {

	protected $table = 'module_dsfsdf';

	protected $fillable = array('textinputasdfasdf','textareaasdfasdf','textinputasdf345vv','textareasdfs324',);
	protected $guarded = array();


}
