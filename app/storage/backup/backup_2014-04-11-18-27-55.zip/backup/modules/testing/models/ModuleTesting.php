<?php
/*
=================================================
Module Name     :   Testing 
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   
Description     :   
===================================================
*/
class ModuleTesting extends Eloquent {

	protected $table = 'module_dsfsdf';

	protected $fillable = array('textinput',);
	protected $guarded = array();


}
