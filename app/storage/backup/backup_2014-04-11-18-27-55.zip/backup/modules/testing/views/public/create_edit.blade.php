@section('content')

<section class="indent">
    <div class="container">
        <div class="accordion-wrapper grid_12">

            @if (Session::has('error_message'))
                <div class="grid_8">
                    <div class="alert alert-error nomargin">
                        Error! {{ Session::get('error_message') }}
                    </div>
                </div>
                <div class="clearfix"></div>
            @endif
            @if (Session::has('success_message'))
                <div class="grid_8">
                    <div class="alert alert-success nomargin">
                        Success! {{ Session::get('success_message') }}
                    </div>
                </div>
                <div class="clearfix"></div>
            @endif

            <h1>{{ $title }}</h1>

            <div class="tabs full-w">
                <ul class="nav nav-tabs"><li class="active"><a href="#tab_1_0" data-toggle="tab">new form</a></li></ul><?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif
<div class="tab-content"><div class="tab-pane active" id="tab_1_0">
<fieldset>

<!-- Form Name -->


<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Text Input</label>
  <div class="controls">
    <input id="textinput" name="textinput" type="text" placeholder="placeholder" class="input-xlarge">
    <p class="help-block">help</p>
  </div>
</div>

</fieldset>

</div></div><div class="form-actions">
                        <button type="submit" class="btn btn-primary" name="form_save">Save</button>

                        <button type="submit" class="btn btn-success" name="form_save_new">Save &amp; New</button>

                        <button type="submit" class="btn btn-primary btn-danger" name="form_close">Close</button>
                    </div>{{ Form::close() }}

            </div>
        </div>
    </div>
</section>

@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
            jQuery(document).ready(function() {
                // While editing fields populate with its data
                @foreach ($fields as $field)
                    <?php
                        $entry->{$field} = preg_replace('~[\r\n]+~', ' ', $entry->{$field});
                        $entry->{$field} = str_replace('\n', " ", $entry->{$field}) ;
                    ?>
                    field = $('[name={{ $field }}]');
                    if (field.is('input[type=radio]')) {
                        field.filter('[value="{{ $entry->{$field} }}"]').attr('checked', true);
                        restore_uniformity();
                    } else {
                        field.val('{{ $entry->{$field} }}');
                    }
                @endforeach
            });
            function restore_uniformity() {
                $.uniform.restore("input[type=radio]");
                $('input[type=radio]').uniform();
            }
        </script>
    @endif

    
@stop
