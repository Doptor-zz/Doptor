<?php

class ModuleAccountBalances extends Eloquent {

	protected $table = 'module_account_balances';
	protected $guarded = array();


	public static function getColumnsNames()
	{
		$columns = DB::select(DB::raw('SHOW COLUMNS FROM `module_account_balances`'));

		$fields = array();

		foreach($columns as $col){
			$field = $col->Field;
			//echo $field; exit;
			$field_rebuild = array_push($fields, $field);
		}
			                    
		//print_r($fields); exit;
		return $fields;
	}



}
