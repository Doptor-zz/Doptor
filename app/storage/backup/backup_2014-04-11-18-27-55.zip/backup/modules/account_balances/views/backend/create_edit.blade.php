@extends('backend.default._layouts._layout')

@section('content')
    <div class="row-fluid">
        <div class="span12">
            <!-- BEGIN FORM widget-->
            <div class="widget box blue tabbable">
                <div class="widget-title">
                    <h4>
                        <span>{{ $title }}</span>
                        &nbsp;
                    </h4>
                </div>
                <div class="widget-body form">
                    <div class="tabbable widget-tabs">
                        <div class="tab-content">
                            <div class="tab-pane active" id="widget_tab1">
                                <!-- BEGIN FORM-->
                                <?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif

<fieldset>

<!-- Form Name -->
<legend>Account Balances</legend>

<table id="JournalTransactionsTable" class="table table-condensed gutter-top">
    <thead>
        <tr>
            <th class="account_pk">Account</th>
            <th class="debit_amount">Debit</th>
            <th class="credit_amount">Credit</th>
        </tr>
    </thead>


    <?php 
        $query = DB::table('module_add_account')->select('module_add_account.id','module_add_account.account_database_table_name','module_add_account.account_name');
        $account = $query->get();
        $count = $query->count();
    ?>
    @if($count!=0)    
        @foreach($account as $acc)
        <tr>
            <td>
                <label class="control-label" for="{{$acc->account_name}}">{{$acc->account_name}}</label>
            </td>

            <td>
                <input onchange="getTotalBalance()" class="debit" id="{{$acc->account_database_table_name.'_'.'debit'}}" name="{{$acc->account_name.'_'.'debit'}}" value="0.00" class="input-xlarge span5" type="text">
            </td>

            <td>
                <input onchange="getTotalBalance()" class="credit" id="{{$acc->account_database_table_name.'_'.'credit'}}" name="{{$acc->account_name.'_'.'credit'}}" value="0.00" class="input-xlarge span5" type="text">
            </td>
        </tr>
        @endforeach

        <tr>
            <td>Debit : <input type='text' name="total_debit" id='total_debit' value='' class="uneditable-input"  /></td>
            <td>Credit : <input type='text' name="total_credit" id='total_credit' value='' class="uneditable-input"  /></td>
            <td>Total : <input type='text' name="total_balance" id='total_balance' value='' class="uneditable-input" /></td>
        </tr>
    @else
        <tr><td> <span style="color:#E52525;" >You must add Account using the Add Account Module first!</span> </td></tr>
    @endif

</table>

    <button class="btn btn-success" type="submit">
        Add Account Balance<i class="icon-plus"></i>
    </button>


</fieldset>

{{ Form::close() }}
                                <!-- END FORM-->
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END FORM widget-->
        </div>
    </div>


{{--Calculation --}}

<script>
    function getDebit()
    {
        var elements = document.getElementsByClassName('debit');
        var debit = 0;

        for(var i = 0; i < elements.length; ++i){
            debit += parseFloat(elements[i].value);
        }

        document.getElementById('total_debit').value = debit;
        return debit;

    }

    function getCredit()
    {

        var elements = document.getElementsByClassName('credit');
        var credit = 0;

        for(var i = 0; i < elements.length; ++i){
            credit += parseFloat(elements[i].value);
        }

        document.getElementById('total_credit').value = credit;
        return credit;
    }

    function getTotalBalance()
    {
        var total_balance = getCredit() - getDebit();
        document.getElementById('total_balance').value = total_balance;
    }



</script>


@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
           jQuery(document).ready(function() {
                @foreach ($fields as $field)
                    $('#{{ $field }} ').val('{{ $entry->{$field} }}');
                @endforeach
           });
        </script>
    @endif
@stop
