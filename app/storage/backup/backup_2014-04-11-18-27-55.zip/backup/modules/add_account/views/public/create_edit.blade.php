@section('content')

<section class="indent">
    <div class="container">
        <div class="accordion-wrapper grid_12">

            @if (Session::has('error_message'))
                <div class="grid_8">
                    <div class="alert alert-error nomargin">
                        Error! {{ Session::get('error_message') }}
                    </div>
                </div>
                <div class="clearfix"></div>
            @endif
            @if (Session::has('success_message'))
                <div class="grid_8">
                    <div class="alert alert-success nomargin">
                        Success! {{ Session::get('success_message') }}
                    </div>
                </div>
                <div class="clearfix"></div>
            @endif

            <h1>{{ $title }}</h1>

            <?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif

<fieldset>

<!-- Form Name -->
<legend>Add Account</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="account_name">Account Name</label>
  <div class="controls">
    <input id="account_name" name="account_name" placeholder="Account Name" class="input-xlarge" type="text">
    <p class="help-block">Account Name</p>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="account_type">Account Type</label>
  <div class="controls">
    <input id="account_type" name="account_type" placeholder="Account Type" class="input-xlarge" type="text">
    <p class="help-block">Account Type</p>
  </div>
</div>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="account_category">Account Category</label>
  <div class="controls">
    <select id="account_category" name="account_category" class="input-xlarge">
      <option>Option one</option>
      <option>Option two</option>
    </select>
  </div>
</div>

</fieldset>

{{ Form::close() }}

            Add Account
        </div>
    </div>
</section>

@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
           jQuery(document).ready(function() {
                @foreach ($fields as $field)
                    $('#{{ $field }} ').val('{{ $entry->{$field} }}');
                @endforeach
           });
        </script>
    @endif
@stop
