@extends('backend.default._layouts._layout')

@section('content')
    <div class="row-fluid">
        <div class="span12">
            <!-- BEGIN FORM widget-->
            <div class="widget box blue tabbable">
                <div class="widget-title">
                    <h4>
                        <span>{{ $title }}</span>
                        &nbsp;
                    </h4>
                </div>
                <div class="widget-body form">
                    <div class="tabbable widget-tabs">
                        <div class="tab-content">
                            <div class="tab-pane active" id="widget_tab1">
                                <!-- BEGIN FORM-->
                                <?php $link_type = ($link_type=="public") ? "" : $link_type . "." ?>
@if (!isset($entry))
{{ Form::open(array("route"=>"{$link_type}modules.".$module_name.".store", "method"=>"POST", "class"=>"form-horizontal", "files"=>true)) }}
@else
{{ Form::open(array("route" => array("{$link_type}modules.".$module_name.".update", $entry->id), "method"=>"PUT", "class"=>"form-horizontal", "files"=>true)) }}
@endif

<fieldset>

<!-- Form Name -->
<legend>Add Account</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="account_name">Account Name</label>
  <div class="controls">
    <input id="account_name" name="account_name" placeholder="Account Name" class="input-xlarge" type="text">
    <p class="help-block">Account Name</p>
  </div>
</div>

<!-- Text input-->

    <input id="account_database_table_name" name="account_database_table_name" placeholder="account_database_table_name" class="input-xlarge" type="hidden">
    



<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="account_type">Account Type</label>
  <div class="controls">
    <input id="account_type" name="account_type" placeholder="Account Type" class="input-xlarge" type="text">
    <p class="help-block">Account Type</p>
  </div>
</div>

<!-- Select Basic -->
<div class="control-group">
  <label class="control-label" for="account_category">Account Category</label>
  <div class="controls">
    <select id="account_category" name="account_category" class="input-xlarge">
    <?php 
    	$query = DB::table('module_add_account_category')->where('status',1)->select('module_add_account_category.id', 'module_add_account_category.category_name');
    	$category = $query->get();
    	$count = $query->count();
    ?>
    @if($count!=0)
	    @foreach($category as $cat)
	      <option value="{{$cat->id}}">{{$cat->category_name}}</option>
	    @endforeach
	@else
		<span style="color:#E52525;" >You must add Account Category using the Account Category Module first!</span>
	@endif
    </select>
  </div>
</div>

	<button class="btn btn-success" type="submit">
                                    Add Account <i class="icon-plus"></i>
                                </button>

</fieldset>

{{ Form::close() }}
                                <!-- END FORM-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END FORM widget-->
        </div>
    </div>
@stop

@section('scripts')
    @parent

    @if (isset($entry))
        <script>
           jQuery(document).ready(function() {
                @foreach ($fields as $field)
                    $('#{{ $field }} ').val('{{ $entry->{$field} }}');
                @endforeach
           });
        </script>
    @endif
@stop
