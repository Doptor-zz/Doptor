<?php

class ModuleAddAccount extends Eloquent {

	protected $table = 'module_add_account';

	protected $fillable = array('account_name','account_type','account_database_table_name','account_category',);
	protected $guarded = array();


}
