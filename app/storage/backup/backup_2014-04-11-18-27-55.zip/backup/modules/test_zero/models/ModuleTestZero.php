<?php
/*
=================================================
Module Name     :   Test zero
Module Version  :   v1
Compatible CMS  :   v1.2
Site            :   
Description     :   
===================================================
*/
class ModuleTestZero extends Eloquent {

	protected $table = 'module_test_zero';

	protected $fillable = array('textinput343c','textinputasdf11','textinputasdfrr','textareaasdf33x',);
	protected $guarded = array();


}
