<?php

class ModuleProductInventory extends Eloquent {

	protected $table = 'module_products_inventory';

	protected $fillable = array('product_name','product_description',);
	protected $guarded = array();


}
